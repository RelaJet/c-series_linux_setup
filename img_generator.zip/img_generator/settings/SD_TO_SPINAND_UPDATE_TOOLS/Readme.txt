[Read Me]
1. Copy U-boot.bin, uImage and rootfs_ubi.img into this folder
2. Execute burn.bat and it will generate FlashImage.bin
3. Copy SdFWCode.bin Updater.txt and FlashImage.bin into SDCARD
4. Boot from SD0 (FAT boot) and it will update those image into spinand
