#!/bin/bash
. ./config.mk 2> /dev/null

raw_kernel=""
embedded_app=""
if [ "$ACTION_CAM_RAW_KERNEL" = "yes" ]; then
  raw_kernel="_rawkernel"
fi
if [ "$ACTION_CAM_EMBEDDED_APP" != "" ]; then
  embedded_app="_embeddedapp"
fi
echo "Generate partitions according to act_partiton$raw_kernel$embedded_app.config"
. ./settings/ACT_PARTITION/act_partiton$raw_kernel$embedded_app.config

MEM_STR=
OLD_MTD_STR=
NEW_MTD_STR=
MTD_PART_NUM=1
##set video size
#get video memory size in config.mk
CVMEM_LINE=`grep -n -F "VIDEO_MEM_SIZE=" ./config.mk`
CVMEM_LINE=`echo $CVMEM_LINE | awk -F"0x" '{print $2}'`
CVMEM_LINE=`echo $CVMEM_LINE | awk -F' ' '{print $1}'`
CVMEM_LINE=`echo $CVMEM_LINE | tr [a-z] [A-Z]`
CVMEM_LINE=`echo "obase=10;ibase=16;$CVMEM_LINE"|bc`
CVMEM_LINE=`expr $CVMEM_LINE / 1024 / 1024`
CVMEM_SIZE="CONFIG_AIT_VIDEO_RESERVED_MBYTE="$CVMEM_LINE
#get video memory size in kernel configure
KVMEM_LINE=`grep -n -F "CONFIG_AIT_VIDEO_RESERVED_MBYTE=" ./$KERNEL_FOLDER/.config`
KVMEM_LINE_NUM=`echo $KVMEM_LINE | awk -F':' '{print $1}'`
KVMEM_SIZE=`echo $KVMEM_LINE | awk -F':' '{print $2}'`
sed -i "$KVMEM_LINE_NUM s/$KVMEM_SIZE/$CVMEM_SIZE/g" ./$KERNEL_FOLDER/.config 

##set total memory size 
#get memory size in config.mk
DDR_SIZE_LINE=`grep -n -F "DDR_SIZE=" ./config.mk`
DDR_SIZE_NUM=`echo $DDR_SIZE_LINE | awk -F'"' '{print $2}'`
DDR_SIZE_NUM=`echo $DDR_SIZE_NUM | awk -F'_' '{print $2}'`
DDR_SIZE_NUM=$DDR_SIZE_NUM"M"
DDR_SIZE_NUM="mem=$DDR_SIZE_NUM"
#get memory size in kernel configure
MEM_LINE=`grep -n -F "CONFIG_CMDLINE=" ./$KERNEL_FOLDER/.config`
MEM_LINE_NUM=`echo $MEM_LINE | awk -F':' '{print $1}'`
for i in $MEM_LINE  
do
	if  echo $i | grep -iq "mem="  ;then
		MEM_STR=$i
	fi
done
#set memory size 
sed -i "$MEM_LINE_NUM s/$MEM_STR/$DDR_SIZE_NUM/g" ./$KERNEL_FOLDER/.config

##set mtdparts
#generate new mtdparts
while [ "$MTD_PART_NUM" != "$TOTAL_PARTITION" ]
do
	if [ "$MTD_PART_NUM" != "$(($TOTAL_PARTITION-1))" ]; then
		NEW_MTD_STR=$NEW_MTD_STR${P_SIZE[$MTD_PART_NUM]}"("${P_NAME[$MTD_PART_NUM]}")",
	else
		NEW_MTD_STR=$NEW_MTD_STR${P_SIZE[$MTD_PART_NUM]}"("${P_NAME[$MTD_PART_NUM]}")"\;
	fi
	MTD_PART_NUM=$(($MTD_PART_NUM+1))
done
#get mtparts in kernel configure
for i in $MEM_LINE  
do
	if  echo $i | grep -iq "mtdparts="  ;then
		OLD_MTD_STR=$i
	fi
done
OLD_MTD_STR=`echo $OLD_MTD_STR | awk -F':' '{print $2}'`
OLD_MTD_STR=`echo $OLD_MTD_STR | awk -F'"' '{print $1}'`
#set new mtdparts
sed -i "$MEM_LINE_NUM s/$OLD_MTD_STR/$NEW_MTD_STR/g" ./$KERNEL_FOLDER/.config

##set rootfs type
if [ "$ROOTFS_TYPE" = "CRAM" ]; then
	FS_LINE=`grep -n -F "rootfstype=squashfs" ./$KERNEL_FOLDER/.config`
	FS_LINE_NUM=`echo $FS_LINE | awk -F':' '{print $1}'`
	sed -i "$FS_LINE_NUM s/rootfstype=squashfs/rootfstype=cramfs/g" ./$KERNEL_FOLDER/.config
elif [ "$ROOTFS_TYPE" = "SQFS" ]; then
	FS_LINE=`grep -n -F "rootfstype=cramfs" ./$KERNEL_FOLDER/.config`
	FS_LINE_NUM=`echo $FS_LINE | awk -F':' '{print $1}'`
	sed -i "$FS_LINE_NUM s/rootfstype=cramfs/rootfstype=squashfs/g" ./$KERNEL_FOLDER/.config
fi

BOOTCMD_LINE=`grep "CONFIG_CMDLINE=" ./$KERNEL_FOLDER/.config`
echo "Create cmd line..."
echo "$BOOTCMD_LINE" > ./settings/ACTCAM/bootcmd_line.txt