#!/bin/sh
#
# Start cpub....
#
#echo "Enter AIT00DUALCPU shell script .."

if [ -e /usr/modules/cpub_mgr_drv.ko ] ; then
#	echo "Insert dual cpu manager"
	insmod /usr/modules/cpub_mgr_drv.ko max_cpub_fw_load_size=-1
	if [ -e /usr/modules/ait_md_drv.ko ]; then
		#echo "Insert dual cpu md driver"
		insmod /usr/modules/ait_md_drv.ko
	fi	
fi
