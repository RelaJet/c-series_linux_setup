#!/bin/sh
. ./config.mk 2> /dev/null
ETC_FIRMWARE=$ROOTFS_FOLDER/etc/firmware
DRIVER_MODULE=$ROOTFS_FOLDER/usr/modules
SENSOR_FOLDER=driver/video
SENSOR_LINK=$DRIVER_MODULE/ait-cam-codec.ko

echo Start to setup video and dual cpu driver
echo ========================================

#set video driver and dual cpu driver
if [ "$DUAL_CPU" = "yes" ] || [ "$ACTION_CAM" = "yes" ]; then

    if [ "$DDR_SIZE" = "MEM_64" ] && [ "$DDR_TYPE" = "MDDR" ]; then
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/512M/MINIBOOT $ETC_FIRMWARE/MINIBOOT
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/512M/AITBOOT $ETC_FIRMWARE/AITBOOT
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/512M/$ACTION_CAM_SENSOR/ALL $ETC_FIRMWARE/ALL
    fi

    if [ "$DDR_SIZE" = "MEM_128" ] && [ "$DDR_TYPE" = "DDR3" ]; then
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/1G/MINIBOOT $ETC_FIRMWARE/MINIBOOT
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/1G/AITBOOT $ETC_FIRMWARE/AITBOOT
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/1G/$ACTION_CAM_SENSOR/ALL $ETC_FIRMWARE/ALL
    fi

    if [ "$DDR_SIZE" = "MEM_240" ] && [ "$DDR_TYPE" = "DDR3" ]; then
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/2G/MINIBOOT $ETC_FIRMWARE/MINIBOOT
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/2G/AITBOOT $ETC_FIRMWARE/AITBOOT
		cp -f $CPUB_RTOS_GCC_IPC_FOLDER/cpub_image/2G/$ACTION_CAM_SENSOR/ALL $ETC_FIRMWARE/ALL
    fi

	if [ "$DUAL_CPU" = "yes" ] && [ "$ACTION_CAM" = "no" ]; then
		cp -f $DUAL_CPU_FOLDER/ALL_DRAM_UCOS2 $ETC_FIRMWARE/ALL_DRAM_UCOS2
		cp -f $DUAL_CPU_FOLDER/ITCM_EXE_UCOS2 $ETC_FIRMWARE/ITCM_EXE_UCOS2
	fi

	if [ "$ACTION_CAM" = "yes" ]; then
		cp -f settings/dual_cpu_act_cam.sh $ROOTFS_FOLDER/etc/init.d/AIT00DUALCPU.sh
		cp -f settings/video_ipc.sh $ROOTFS_FOLDER/etc/init.d/AIT00VideoDrv.sh

		if [ "$DUAL_CPU_MD" = "yes" ]; then
			cp -f linux-3.2.7/arch/arm/mach-mcrv2/cpucomm/md_algo/ait_md_drv.ko $DRIVER_MODULE/ait_md_drv.ko
		fi
	else
		cp -f settings/dual_cpu.sh $ROOTFS_FOLDER/etc/init.d/AIT00DUALCPU.sh
		cp -f settings/video.sh $ROOTFS_FOLDER/etc/init.d/AIT00VideoDrv.sh

		if [ "$DUAL_CPU_MD" = "yes" ]; then
			cp -f linux-3.2.7/arch/arm/mach-mcrv2/cpucomm/md_algo/ait_md_drv.ko $DRIVER_MODULE/ait_md_drv.ko
		fi

		if [ "$DUAL_CPU_AAC" = "yes" ]; then
			cp -f linux-3.2.7/arch/arm/mach-mcrv2/cpucomm/aac_algo/ait_aac_drv.ko $DRIVER_MODULE/ait_aac_drv.ko
		fi
	fi

	if [ -e linux-3.2.7/arch/arm/mach-mcrv2/cpucomm/cpub_mgr_drv.ko ]; then
		cp -f linux-3.2.7/arch/arm/mach-mcrv2/cpucomm/cpub_mgr_drv.ko $DRIVER_MODULE/cpub_mgr_drv.ko
	else
		echo "ERROR: no driver of communication for cpub"
	fi
fi

#set video memory size
VIDEO_SH=$ROOTFS_FOLDER/etc/init.d/AIT00VideoDrv.sh
LINE=`grep -n -F "resv_dram_size=" $VIDEO_SH`
LINE_NUM=`echo $LINE | awk -F':' '{print $1}'`
ORIG_SIZE=`echo $LINE | awk -F"resv_dram_size=" '{print $2}'`
ORIG_SIZE=`echo $ORIG_SIZE | awk -F' ' '{print $1}'`

sed -i "$LINE_NUM s/resv_dram_size=$ORIG_SIZE/resv_dram_size=$VIDEO_MEM_SIZE/g" $VIDEO_SH

#copy sensor driver
if [ -e $SENSOR_FOLDER/$SENSOR_NAME ]; then
    cp -f $SENSOR_FOLDER/$SENSOR_NAME $DRIVER_MODULE/$SENSOR_NAME
    rm -f $SENSOR_LINK
    ln -s $SENSOR_NAME $SENSOR_LINK
else
    echo "ERROR: No sensor driver $SENSOR_NAME"
fi

echo =========================================
echo finish to setup video and dual cpu driver
