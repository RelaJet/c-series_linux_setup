[Read Me]
1. Copy AITBOOT(in aitbootimage folder) U-boot.bin, uImage and rootfs_cram.img into this folder
2. Execute burn.bat and it will generate flash_uboot
3. Copy SdFWCode.bin SfFwCode.bin flash_uboot uImage rootfs_cram.img and Updater.txt into SDCARD
4. Boot from SD0 (FAT boot) and it will update those image into spiflash
