#!/bin/sh
. ./config.mk 2> /dev/null
DRIVER_MODULE=$ROOTFS_FOLDER/usr/modules
WIFI_FOLDER=driver/wifi
BT_FOLDER=driver/bluetooth
ETC_FIRMWARE=$ROOTFS_FOLDER/etc/firmware
USR_BIN=$ROOTFS_FOLDER/usr/bin
USR_LIB=$ROOTFS_FOLDER/usr/lib
CLOUDAPP_PATH=./app/$CLOUD_APP_FOLDER
SERVICEAPP_PATH=./app/$SERVICE_APP_FOLDER

echo Start to Setup WIFI driver
echo ==========================

#setup wifi settings
if [ -e linux-3.2.7/drivers/net/wireless/bcmdhd.1.201.59.x.cn/$WIFI_NAME ]; then
	cp -f linux-3.2.7/drivers/net/wireless/bcmdhd.1.201.59.x.cn/$WIFI_NAME $WIFI_FOLDER/$WIFI_NAME
elif [ -e linux-3.2.7/drivers/net/wireless/bcmdhd.1.88.45.x.cn/$WIFI_NAME ]; then
	cp -f linux-3.2.7/drivers/net/wireless/bcmdhd.1.88.45.x.cn/$WIFI_NAME $WIFI_FOLDER/$WIFI_NAME
else
	echo "warning: no driver of AP6xxx Wi-Fi driver"
	wifi_in_kernel="yes"
fi
#
# remove link
#
rm -rf $ROOTFS_FOLDER/usr/wireless
if [ "$ACTION_CAM" = "yes" ]; then
  echo "$ACTION_CAM_WIFI_TYPE" > $ROOTFS_FOLDER/etc/init.d/WIFITYPE

fi

case $WIFI_MODULE in
AP6181 | AP6210)
	if [ "$WIFI_MODULE" = "AP6210" ]; then
		WIFI_FILE_NAME=ap6210
	else
		WIFI_FILE_NAME=ap6181
	fi
	# move here if build as kernel driver
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE	
	if [ -e $WIFI_FOLDER/$WIFI_NAME ] || [ "$wifi_in_kernel" = "yes" ]; then
		cp -f $WIFI_FOLDER/$WIFI_NAME $DRIVER_MODULE/$WIFI_NAME
#		rm -rf $ETC_FIRMWARE
#		mkdir $ETC_FIRMWARE
		cp -a $WIFI_FOLDER/firmware/ap6181_6210 $ETC_FIRMWARE/$WIFI_FILE_NAME
		ln -s $WIFI_FILE_NAME/fw_bcm40181a2_rxglom-rc107.bin $ETC_FIRMWARE/fw_bcm40181a2.bin
		ln -s $WIFI_FILE_NAME/fw_bcm40181a2_rxglom-rc107.bin $ETC_FIRMWARE/fw_bcm40181a2_apsta.bin
		ln -s $WIFI_FILE_NAME/fw_bcm40181a2_rxglom-rc107.bin $ETC_FIRMWARE/fw_bcm40181a2_p2p.bin
		ln -s $WIFI_FILE_NAME/fw_bcm40181a2_rxglom-rc107.bin $ETC_FIRMWARE/fw_bcmdhd.bin
		
		ln -s $WIFI_FILE_NAME/nvram.txt $ETC_FIRMWARE/nvram.txt
		if [ "$WIFI_MFG" = "yes" ]; then
			cp -a $WIFI_FOLDER/firmware/ap6181/fw_bcmdhd_mfg.bin $ETC_FIRMWARE/$WIFI_FILE_NAME
			ln -s $WIFI_FILE_NAME/fw_bcmdhd_mfg.bin $ETC_FIRMWARE/fw_bcm40181a2_mfg.bin
		fi
		rm -rf $ROOTFS_FOLDER/usr/ap6*
		if [ "$CLOUD" = "yes" ]; then
			cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			ln -s ./$WIFI_NAME $DRIVER_MODULE/bcm_wlan_ap6181.ko
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		if [ "$WIFI_MODULE" = "AP6210" ]; then
			if [ "$BLUETOOTH" = "yes" ]; then
				cp -a $BT_FOLDER/firmware/$WIFI_FILE_NAME/bcm20710a1.hcd $ETC_FIRMWARE
				cp -a $BT_FOLDER/bt_setup/brcm_patchram_plus $USR_BIN
				cp -a $BT_FOLDER/bt_setup/bt_6210init.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
				cp -a $BT_FOLDER/bt_setup/bt_reset.sh $USR_BIN
			fi
		fi
	else
		echo "ERROR: No wifi driver"
	fi
	;;

AP6330 | AP6331)
	if [ "$WIFI_MODULE" = "AP6330" ]; then
		WIFI_FILE_NAME=ap6330
	else
		WIFI_FILE_NAME=ap6331
	fi
    echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE	
	if [ -e $WIFI_FOLDER/$WIFI_NAME ] || [ "$wifi_in_kernel" = "yes" ]; then
		cp -f $WIFI_FOLDER/$WIFI_NAME $DRIVER_MODULE/$WIFI_NAME
#		rm -rf $ETC_FIRMWARE
#		mkdir $ETC_FIRMWARE
		cp -r $WIFI_FOLDER/firmware/ap6330_6331 $ETC_FIRMWARE/$WIFI_FILE_NAME
		ln -s $WIFI_FILE_NAME/fw_bcm40183b2_ag.bin $ETC_FIRMWARE/fw_bcm40183b2_ag.bin
		ln -s $WIFI_FILE_NAME/fw_bcm40183b2_ag.bin $ETC_FIRMWARE/fw_bcm40183b2_ag_apsta.bin
		ln -s $WIFI_FILE_NAME/fw_bcm40183b2_ag.bin $ETC_FIRMWARE/fw_bcm40183b2_ag_p2p.bin
		ln -s $WIFI_FILE_NAME/nvram.txt $ETC_FIRMWARE/nvram.txt
		if [ "$WIFI_MFG" = "yes" ]; then
			ln -s $WIFI_FILE_NAME/fw_bcm4330b2_ag_mfg.bin $ETC_FIRMWARE/fw_bcm40183b2_ag_mfg.bin
		fi
		rm -rf $ROOTFS_FOLDER/usr/ap6*
		if [ "$CLOUD" = "yes" ]; then
			cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME		 
			ln -s ./$WIFI_NAME $DRIVER_MODULE/bcm_wlan_ap6330.ko
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		if [ "$WIFI_MODULE" = "AP6330" ]; then
			if [ "$BLUETOOTH" = "yes" ]; then
				cp -a $BT_FOLDER/firmware/$WIFI_FILE_NAME/bcm40183b2.hcd $ETC_FIRMWARE
				cp -a $BT_FOLDER/bt_setup/brcm_patchram_plus $USR_BIN
				cp -a $BT_FOLDER/bt_setup/bt_6330init.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
				cp -a $BT_FOLDER/bt_setup/bt_reset.sh $USR_BIN
			fi
		fi
	else
		echo "ERROR: No wifi driver"
	fi
	;;

AP6212 | AP6212A)
  if [ "$WIFI_MODULE" = "AP6212" ]; then
    WIFI_FILE_NAME=ap6212
  else
    WIFI_FILE_NAME=ap6212a
  fi
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
    if [ -e $WIFI_FOLDER/$WIFI_NAME ] || [ "$wifi_in_kernel" = "yes" ]; then
    cp -f $WIFI_FOLDER/$WIFI_NAME $DRIVER_MODULE/$WIFI_NAME
    # rm -rf $ETC_FIRMWARE
    # mkdir $ETC_FIRMWARE
		if [ "$WIFI_MODULE" = "AP6212" ]; then
			cp -r $WIFI_FOLDER/firmware/ap6212_6212a/AP6212_4.2/Wi-Fi $ETC_FIRMWARE/$WIFI_FILE_NAME
			ln -s $WIFI_FILE_NAME/fw_bcm43438a0.bin $ETC_FIRMWARE/fw_bcm43438a0.bin
			ln -s $WIFI_FILE_NAME/fw_bcm43438a0_apsta.bin $ETC_FIRMWARE/fw_bcm43438a0_apsta.bin
			ln -s $WIFI_FILE_NAME/fw_bcm43438a0_p2p.bin $ETC_FIRMWARE/fw_bcm43438a0_p2p.bin
			ln -s $WIFI_FILE_NAME/fw_bcm43438a0.bin $ETC_FIRMWARE/fw_bcmdhd.bin
			
			ln -s $WIFI_FILE_NAME/nvram_ap6212.txt $ETC_FIRMWARE/nvram.txt
		else
		  if [ "$ACTION_CAM" = "yes" ]; then
		    cp -r $WIFI_FOLDER/firmware/BCM43438a1 $ETC_FIRMWARE/$WIFI_FILE_NAME

		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.0310 $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.0310 $ETC_FIRMWARE/fw_bcmdhd.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.0324 $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.0324 $ETC_FIRMWARE/fw_bcmdhd.bin
        
        # no ring tone ver
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1_0328.bin $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1_0328.bin $ETC_FIRMWARE/fw_bcmdhd.bin

		    ln -s $WIFI_FILE_NAME/fw_bcm43438a1_0329_1.bin $ETC_FIRMWARE/fw_bcm43438a1.bin
		    ln -s $WIFI_FILE_NAME/fw_bcm43438a1_0329_1.bin $ETC_FIRMWARE/fw_bcmdhd.bin


		    # test new firmware from 20170223 , wifi uart is on
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.20170223 $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.20170223 $ETC_FIRMWARE/fw_bcmdhd.bin


		    # test new firmware from 20170213
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.20170209 $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin.20170209 $ETC_FIRMWARE/fw_bcmdhd.bin


		    # normal suspend current & current used firmware
		    #ln -s $WIFI_FILE_NAME/7.46.57.4.bin $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/7.46.57.4.bin $ETC_FIRMWARE/fw_bcmdhd.bin
		    
		    
		    # abnormal suspend current
		    #ln -s $WIFI_FILE_NAME/43430r1_swoob1.bin $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/43430r1_swoob1.bin $ETC_FIRMWARE/fw_bcmdhd.bin
		    
		    # normal suspend current
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.7.46.57.4.ap.r1.bin $ETC_FIRMWARE/fw_bcm43438a1.bin
		    #ln -s $WIFI_FILE_NAME/fw_bcm43438a1.7.46.57.4.ap.r1.bin $ETC_FIRMWARE/fw_bcmdhd.bin
		    
		    ln -s $WIFI_FILE_NAME/nvram.txt $ETC_FIRMWARE/nvram.txt
		    ln -s $WIFI_FILE_NAME/config.txt $ETC_FIRMWARE/config.txt
		  else
			  cp -r $WIFI_FOLDER/firmware/ap6212_6212a/AP6212A_4.2/Wi-Fi $ETC_FIRMWARE/$WIFI_FILE_NAME
  			ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin $ETC_FIRMWARE/fw_bcm43438a1.bin
  			ln -s $WIFI_FILE_NAME/fw_bcm43438a1_apsta.bin $ETC_FIRMWARE/fw_bcm43438a1_apsta.bin
  			ln -s $WIFI_FILE_NAME/fw_bcm43438a1_p2p.bin $ETC_FIRMWARE/fw_bcm43438a1_p2p.bin
  			ln -s $WIFI_FILE_NAME/fw_bcm43438a1.bin $ETC_FIRMWARE/fw_bcmdhd.bin
  			ln -s $WIFI_FILE_NAME/nvram_ap6212a.txt $ETC_FIRMWARE/nvram.txt
			fi
		fi
    rm -rf $ROOTFS_FOLDER/usr/ap6*
    if [ "$CLOUD" = "yes" ]; then
            cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
            ln -s ./$WIFI_NAME $DRIVER_MODULE/bcm_wlan_ap6212.ko
    else
            cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
    fi
    #replace the original one
    if [ "$ACTION_CAM" = "yes" ]; then
      cp -f $WIFI_FOLDER/firmware/BCM43438a1/sta.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/sta.sh
    fi
    
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless

		if [ "$BLUETOOTH" = "yes" ]; then
			if [ "$WIFI_MODULE" = "AP6212" ]; then
				cp -a $WIFI_FOLDER/firmware/ap6212_6212a/AP6212_4.2/BT/bcm43438a0.hcd $ETC_FIRMWARE
				cp -a $BT_FOLDER/bt_setup/bt_6212init.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			else
				cp -a $WIFI_FOLDER/firmware/ap6212_6212a/AP6212A_4.2/BT/bcm43438a1.hcd $ETC_FIRMWARE
				cp -a $BT_FOLDER/bt_setup/bt_6212Ainit.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			fi
			cp -a $BT_FOLDER/bt_setup/brcm_patchram_plus $USR_BIN
			cp -a $BT_FOLDER/bt_setup/bt_reset.sh $USR_BIN
		fi
    else
      echo "ERROR: No wifi driver"
    fi
    ;;

AP6233F)
	if [ "$WIFI_MODULE" = "AP6233F" ]; then
		WIFI_FILE_NAME=ap6233f
	fi
    echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	if [ -e $WIFI_FOLDER/$WIFI_NAME ]; then
		cp -f $WIFI_FOLDER/$WIFI_NAME $DRIVER_MODULE/$WIFI_NAME
#		rm -rf $ETC_FIRMWARE
#		mkdir $ETC_FIRMWARE
		cp -r $WIFI_FOLDER/firmware/ap6233f $ETC_FIRMWARE/$WIFI_FILE_NAME
		ln -s $WIFI_FILE_NAME/fw_bcm4334b1_ag.bin $ETC_FIRMWARE/fw_bcm4334b1_ag.bin
		ln -s $WIFI_FILE_NAME/fw_bcm4334b1_ag.bin $ETC_FIRMWARE/fw_bcm4334b1_ag_apsta.bin
		ln -s $WIFI_FILE_NAME/fw_bcm4334b1_ag.bin $ETC_FIRMWARE/fw_bcm4334b1_ag_p2p.bin
		ln -s $WIFI_FILE_NAME/nvram.txt $ETC_FIRMWARE/nvram.txt
		if [ "$WIFI_MFG" = "yes" ]; then
			ln -s $WIFI_FILE_NAME/fw_bcm4334b1_ag_mfg.6.10.58.bin $ETC_FIRMWARE/fw_bcm4334b1_ag_mfg.bin
		fi
		rm -rf $ROOTFS_FOLDER/usr/ap6*
		if [ "$CLOUD" = "yes" ]; then
			cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME		 
			ln -s ./$WIFI_NAME $DRIVER_MODULE/bcm_wlan_ap6233f.ko
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
	else
		echo "ERROR: No wifi driver"
	fi
	;;

AR1021)
	if [ "$WIFI_MODULE" = "AR1021" ]; then
		WIFI_FILE_NAME=ar1021
		if [ "$WIFI_MFG" = "yes" ]; then
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MFG/drivers/compat.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MFG/drivers/cfg80211.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MFG/drivers/ath6kl_usb.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MFG/tools/athtestcmd $USR_BIN
		else
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/compat.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/cfg80211.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ath6kl_usb.ko $DRIVER_MODULE
		fi
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ath6k $ROOTFS_FOLDER/etc
		if [ "$CLOUD" = "yes" ]; then
			cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			# Cloud setup AP/STA
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadAR1021_ap.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		# Gentle reminder: The AR1021 is use specific wireless tools.
		# If you want to change back other modules, please keep original wireless tools.
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/tools/hostapd* $ROOTFS_FOLDER/usr/sbin
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/tools/wpa_* $USR_BIN
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/tools/iw $USR_BIN
	fi
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;

MT5931)
	if [ "$WIFI_MODULE" = "MT5931" ]; then
		# if use the MT5931, please add mt5931 of kernel and re-build.
		WIFI_FILE_NAME=mt5931
		cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/wlan.ko $DRIVER_MODULE
		cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/WIFI_RAM_CODE $ETC_FIRMWARE
		if [ "$CLOUD" = "yes" ]; then
			cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		fi
		rm -rf $ROOTFS_FOLDER/usr/ap6181
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadmt5931_ap $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ap_conf.sh $USR_BIN/ap_conf.sh
	fi
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;

MT7601U)
	if [ "$WIFI_MODULE" = "MT7601U" ]; then
		WIFI_FILE_NAME=mt7601u
		cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/mt7601Uap.ko $DRIVER_MODULE
		cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/RT2870AP.dat $ROOTFS_FOLDER/etc
		if [ "$CLOUD" = "yes" ]; then
			cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadmt7601u_ap $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ap_conf_mt.sh $USR_BIN/ap_conf_mt.sh
	fi
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;

MT7603U)
	if [ "$WIFI_MODULE" = "MT7603U" ]; then
		WIFI_FILE_NAME=mt7603u
		CONNECTION_TOOL=wpa_supplicant #iwpriv
		if [ "$CONNECTION_TOOL" = "iwpriv" ]; then
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/prealloc.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/mt7603u_ap.ko $DRIVER_MODULE
			mkdir $ROOTFS_FOLDER/etc/Wireless
			mkdir $ROOTFS_FOLDER/etc/Wireless/RT2870AP
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/RT2870AP.dat $ROOTFS_FOLDER/etc/Wireless/RT2870AP
			if [ "$CLOUD" = "yes" ]; then
				cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
				# cloud setup AP/STA
			else
				cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
				cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadmt7603u_ap.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
				cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadmt7603u_sta.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/sta.sh
			fi
			cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ap_conf_mt.sh $USR_BIN/ap_conf_mt.sh
		else #By wpa_supplicant
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/mtprealloc.ko $DRIVER_MODULE
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/mt7603u_sta.ko $DRIVER_MODULE
			mkdir $ROOTFS_FOLDER/etc/Wireless
			mkdir $ROOTFS_FOLDER/etc/Wireless/RT2870STA
			cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MT7603USTA.dat $ROOTFS_FOLDER/etc/Wireless/RT2870STA
			if [ "$CLOUD" = "yes" ]; then
				cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			else
				cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
				cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadmt7603u_JEDI_ap.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
				cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/loadmt7603u_JEDI_sta.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/sta.sh
			fi
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MT7603_2T2R_V12.bin $ROOTFS_FOLDER/etc/RT30xxEEPROM.bin
	fi
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;

MT7687)
	WIFI_FILE_NAME=mt7687
	echo "Compiling iot-tool..."
	$PWD/${CROSS_COMPILE}gcc -o linux-3.2.7/drivers/net/iot/mtk/mt7687/iot-tool -g linux-3.2.7/drivers/net/iot/mtk/mt7687/iot-tool.c -I linux-3.2.7/drivers/net/iot/mtk/mt7687/
	cp -f linux-3.2.7/drivers/net/iot/mtk/mt7687/iot-tool $USR_BIN/iot-tool
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;

CC3200)
  WIFI_FILE_NAME=cc3200
  echo "Compiling iot-tool..."
	$PWD/${CROSS_COMPILE}gcc -o linux-3.2.7/drivers/net/iot/ti/cc3200/iot-tool -g linux-3.2.7/drivers/net/iot/ti/cc3200/iot-tool.c -I linux-3.2.7/drivers/net/iot/ti/cc3200/
	cp -f linux-3.2.7/drivers/net/iot/ti/cc3200/iot-tool $USR_BIN/iot-tool
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;
  
RTL8189ES)
	if [ "$WIFI_MODULE" = "RTL8189ES" ]; then
		# if use the RTL8189ES, please add rtl8189 of kernel and re-build.
		WIFI_FILE_NAME=rtl8189es
		cp -f $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/8189es.ko $DRIVER_MODULE
		if [ "$CLOUD" = "yes" ]; then
			#cp -a $WIFI_FOLDER/cloud_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			mkdir $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
			cp -a $WIFI_FOLDER/cloud_setup/ap.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
			cp -a $WIFI_FOLDER/cloud_setup/sta.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/sta.sh 
		else
			cp -a $WIFI_FOLDER/wlan_setup $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME
		        cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ap.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/ap.sh
			cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/sta.sh $ROOTFS_FOLDER/usr/$WIFI_FILE_NAME/sta.sh
		fi
		ln -s ./$WIFI_FILE_NAME  $ROOTFS_FOLDER/usr/wireless
		cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/ap_conf_rtl.sh $USR_BIN/ap_conf_rtl.sh
		if [ "$WIFI_MFG" = "yes" ]; then
			cp -af $WIFI_FOLDER/firmware/$WIFI_FILE_NAME/MFG/rtwpriv $USR_BIN
		fi
	fi
	echo "$WIFI_FILE_NAME" > $ROOTFS_FOLDER/etc/init.d/WIFIDEFINE
	;;

*)
	echo "WARNNING: unknown wifi module"
esac

if [ "$WIFI_MODULE" = "RTL8189ES" ] || [ "$WIFI_MODULE" = "AR1021" ] ; then
	echo " "
else
	cp -af $WIFI_FOLDER/hostapd $ROOTFS_FOLDER/usr/sbin
	cp -af $WIFI_FOLDER/wpa_supplicant $ROOTFS_FOLDER/usr/bin
fi

#For Wi-Fi MFG mode
if [ "$ACTION_CAM" = "yes" ]; then
  cp -af $WIFI_FOLDER/sleep/$WIFI_FILE_NAME.sh $ROOTFS_FOLDER/usr/bin/wifisleep.sh
  cp -af $WIFI_FOLDER/connect/$WIFI_FILE_NAME.sh $ROOTFS_FOLDER/usr/bin/wificonnect.sh
  if [ "$ACTION_CAM_WIFI_TYPE" != "iot" ]; then
    cp -af $WIFI_FOLDER/wl $USR_BIN
    cp -af $WIFI_FOLDER/dhd $USR_BIN
  fi
else
  if [ "$WIFI_MFG" = "yes" ]; then
  	cp -af $WIFI_FOLDER/wl $USR_BIN
  fi
fi

#Copy BlueZ tools
if [ "$BLUETOOTH" = "yes" ]; then
	cp -f $BT_FOLDER/blueZ_binary/* $USR_BIN
	cp -af $BT_FOLDER/blueZ_lib/* $USR_LIB
fi

echo ===========================
echo finish to Setup WIFI driver
