#!/bin/sh
#Please don't moditfy this shell, because it could damage your system
FAT_FOLDER=./fat_partition_1
EXT_FOLDER=./ext_partition_2
IMAGE_FOLDER=../image
ROOTFS_FOLDER=$IMAGE_FOLDER/root_file_system

if [ $# -lt 1 ]; then
        echo Please input your sd card device node and make sure it has two partitions
        echo Sd card device coulde be \"sdx\" or \"mmcblkx\"
        echo example1: copy_image.sh /dev/sdb
        echo example2: copy_image.sh /dev/mmcblk0
        exit
fi

sudo rm -rf $FAT_FOLDER $EXT_FOLDER
mkdir $FAT_FOLDER $EXT_FOLDER

#mount file system
if [ `echo $1| grep -c "mmc"` -gt 0 ]; then
sudo mount $1"p1" $FAT_FOLDER 
sudo mount $1"p2" $EXT_FOLDER
else
sudo mount $1"1" $FAT_FOLDER
sudo mount $1"2" $EXT_FOLDER
fi

#copy root_file_system
sudo cp -rf $ROOTFS_FOLDER/* $EXT_FOLDER/
sync

#copy image
sudo cp -f $IMAGE_FOLDER/uImage $FAT_FOLDER/
sudo cp -f $IMAGE_FOLDER/U-boot.bin $FAT_FOLDER/
sudo cp -f $IMAGE_FOLDER/SdFwCode.bin $FAT_FOLDER/
sync

#mount file system
if [ `echo $1| grep -c "mmc"` -gt 0 ]; then
sudo umount $1"p1"
sudo umount $1"p2"
else
sudo umount $1"1"
sudo umount $1"2"
fi
sync

rm -rf $FAT_FOLDER $EXT_FOLDER
