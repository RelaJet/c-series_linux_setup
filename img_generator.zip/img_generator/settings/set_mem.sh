#!/bin/sh
. ./config.mk 2> /dev/null

#set memory size
BOARD_CONFIG=`echo $U_BOOT_CONFIG | sed "s/_config//"`
LINE=`grep -n -F "$BOARD_CONFIG" ./u-boot-2013.01/boards.cfg`
LINE_NUM=`echo $LINE | awk -F':' '{print $1}'`
sed -i "$LINE_NUM s/MEM_32/$DDR_SIZE/g" ./$U_BOOT_FOLDER/boards.cfg
sed -i "$LINE_NUM s/MEM_64/$DDR_SIZE/g" ./$U_BOOT_FOLDER/boards.cfg
sed -i "$LINE_NUM s/MEM_128/$DDR_SIZE/g" ./$U_BOOT_FOLDER/boards.cfg
sed -i "$LINE_NUM s/MEM_256/$DDR_SIZE/g" ./$U_BOOT_FOLDER/boards.cfg

#set rootfs type
if [ "$ROOTFS_TYPE" = "CRAM" ]; then
        FS_LINE=`grep -n -F "rootfstype=squashfs" ./$U_BOOT_FOLDER/include/configs/ait6366_evb.h`
        FS_LINE_NUM=`echo $FS_LINE | awk -F':' '{print $1}'`
        sed -i "$FS_LINE_NUM s/rootfstype=squashfs/rootfstype=cramfs/g" ./$U_BOOT_FOLDER/include/configs/ait6366_evb.h
elif [ "$ROOTFS_TYPE" = "SQFS" ]; then
        FS_LINE=`grep -n -F "rootfstype=cramfs" ./$U_BOOT_FOLDER/include/configs/ait6366_evb.h`
        FS_LINE_NUM=`echo $FS_LINE | awk -F':' '{print $1}'`
        sed -i "$FS_LINE_NUM s/rootfstype=cramfs/rootfstype=squashfs/g" ./$U_BOOT_FOLDER/include/configs/ait6366_evb.h
fi

