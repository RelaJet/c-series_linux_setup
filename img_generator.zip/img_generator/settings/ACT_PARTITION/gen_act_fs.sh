#!/bin/bash
. ./config.mk 2> /dev/null

raw_kernel=""
embedded_app=""
if [ "$ACTION_CAM_RAW_KERNEL" = "yes" ]; then
  raw_kernel="_rawkernel"
fi
if [ "$ACTION_CAM_EMBEDDED_APP" != "" ]; then
  embedded_app="_embeddedapp"
fi
. ./settings/ACT_PARTITION/act_partiton$raw_kernel$embedded_app.config


IMAGE=./image
MTD_PART_NUM=1

echo Start to Generate Customer Partition
echo ====================================

if [ ! `command -v mkcramfs` ]; then
	echo "Please get \"mkcramfs\" (sudo apt-get install cramfsprogs)"
	exit 1
fi

if [ ! `command -v mksquashfs` ]; then
	echo "Please get \"mksquashfs\" (sudo apt-get install squashfs-tools)"
	exit 1
fi

if [ ! `command -v mkfs.jffs2` ]; then
	echo "Please get \"mkfs.jffs2\" (sudo apt-get install mtd-utils)"
	exit 1
fi

echo "+++++++++++++++++++++++( image/ )+++++++++++++++++++++++++"
while [ "$MTD_PART_NUM" != "$TOTAL_PARTITION" ]
do
  if [ "${P_NAME[$MTD_PART_NUM]}" == "kernel" ]; then
    if [ "$ACTION_CAM_RAW_KERNEL" = "yes" ]; then
      echo "Warning : Please make sure uImage.Raw size is not over ${P_SIZE[$MTD_PART_NUM]}"
    else
      echo "Warning : Please make sure uImage size is not over ${P_SIZE[$MTD_PART_NUM]}"
    fi  
  fi
  if [ "${P_NAME[$MTD_PART_NUM]}" == "embedded" ]; then
    echo "Warning : Please make sure embedded_app.img size is not over ${P_SIZE[$MTD_PART_NUM]}"
  fi
  MTD_PART_NUM=$(($MTD_PART_NUM+1))
done
echo "+++++++++++++++++++++++( image/ )+++++++++++++++++++++++++"

MTD_PART_NUM=1

while [ "$MTD_PART_NUM" != "$TOTAL_PARTITION" ]
do
	if [ "${P_GEN[$MTD_PART_NUM]}" == "Yes" ]; then
		case "${P_TYPE[$MTD_PART_NUM]}" in
		jffs2)
			echo Generate jffs2 for ${P_NAME[$MTD_PART_NUM]}. Parition number : $(($MTD_PART_NUM-1)). Image Name : ${P_NAME[$MTD_PART_NUM]}"_"jffs2.img
			rm -f $IMAGE/${P_NAME[$MTD_PART_NUM]}"_"jffs2.img
			sudo mkfs.jffs2 -r ${P_FOLDER[$MTD_PART_NUM]} -e 0x10000 -o $IMAGE/${P_NAME[$MTD_PART_NUM]}"_"jffs2.img
			;;
		cramfs)
			echo Generate cramfs for ${P_NAME[$MTD_PART_NUM]}. Parition number : $(($MTD_PART_NUM-1)). Image Name : ${P_NAME[$MTD_PART_NUM]}"_"cram.img
			rm -f $IMAGE/${P_NAME[$MTD_PART_NUM]}"_"cram.img
			sudo mkcramfs ${P_FOLDER[$MTD_PART_NUM]} $IMAGE/${P_NAME[$MTD_PART_NUM]}"_"cram.img
			;;
		sqfslzo)
			echo Generate Squashfs \(lzo\) for ${P_NAME[$MTD_PART_NUM]}. Parition number : $(($MTD_PART_NUM-1)). Image Name : ${P_NAME[$MTD_PART_NUM]}"_"sqfslzo.img
			rm -f $IMAGE/${P_NAME[$MTD_PART_NUM]}"_"sqfslzo.img
			sudo mksquashfs ${P_FOLDER[$MTD_PART_NUM]} $IMAGE/${P_NAME[$MTD_PART_NUM]}"_"sqfslzo.img -noappend -comp lzo
			;;
		*)
			echo ERROR: not support file system type ${P_TYPE[$MTD_PART_NUM]}
			exit 1
			;;
		esac
    fi
	MTD_PART_NUM=$(($MTD_PART_NUM+1))
done
echo =====================================
echo Finish to Generate Customer Partition
