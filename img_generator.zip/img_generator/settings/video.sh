#!/bin/sh
#
# Start the video driver....
#
echo "Enter AIT00VideoDrv shell script ..."

insmod /usr/modules/ait-cam-codec.ko resv_dram_size=0x1800000
