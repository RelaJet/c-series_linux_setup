#!/bin/sh
if [ $# -lt 3 ]; then
	echo Please input your sd card device node and the percentage of partition 1 and 2
	echo Sd card device coulde be \"sdx\" or \"mmcblkx\"
	echo example1: partition.sh /dev/sdb 20 80
	echo example2: partition.sh /dev/mmcblk0 50 50
	exit
fi

if [ $(($2 + $3)) -gt 100 ]; then
	echo total percentage are more than 100
	exit
fi

sudo parted -s $1 mklabel msdos
sudo parted -s $1 mkpart primary fat32 0% $2%
sudo parted -s $1 mkpart primary ext4 $2% $(($2+$3))%
if [ `echo $1| grep -c "mmc"` -gt 0 ]; then
sudo mkfs.vfat $1"p1"
sudo mkfs.ext4 -F $1"p2"
else
sudo mkfs.vfat $1"1"
sudo mkfs.ext4 -F $1"2"
fi
