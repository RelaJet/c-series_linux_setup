#!/bin/sh
. ./config.mk 2> /dev/null
DEC_NUM=`date +"%Y%m%d%H%M"`
DATE_NUM=`echo "obase=10; ${DEC_NUM}" | bc`
CGI_PATH=./app/$CGI_FOLDER
CLOUDAPP_PATH=./app/$CLOUD_APP_FOLDER
SERVICEAPP_PATH=./app/$SERVICE_APP_FOLDER
USR_BIN=$ROOTFS_FOLDER/usr/bin

echo Start to setup application
echo ==========================

#copy application
if [ "$BUILD_APP" = "yes" ]; then
#copy cloud app and fw version
	echo AITCAM-6366-$DATE_NUM- > fwversion
	if [ "$CLOUD" = "yes" ]; then
		sudo cp -f fwversion $ROOTFS_FOLDER/usr/fwversion_ait
		if [ "$DUAL_CPU" = "yes" ]; then
			sudo rm $ROOTFS_FOLDER/usr/cloud_daemon/mdcapture_y
			sudo cp -f $CLOUDAPP_PATH/bin/mdcapture_y_orig $ROOTFS_FOLDER/usr/cloud_daemon
			sudo cp -f $CLOUDAPP_PATH/bin/mdcapture_y_cpub $ROOTFS_FOLDER/usr/cloud_daemon
			sudo ln -s ./mdcapture_y_cpub $ROOTFS_FOLDER/usr/cloud_daemon/mdcapture_y
    	else
			sudo cp -f $CLOUDAPP_PATH/bin/mdcapture_y_orig $ROOTFS_FOLDER/usr/cloud_daemon/mdcapture_y
		fi
		sudo cp -f $CLOUDAPP_PATH/bin/AVAPIs_Server $ROOTFS_FOLDER/usr/cloud_daemon/AVAPIs_Server
	else
		if [ "$CLOUD_APP" = "yes" ]; then
			sudo cp -f fwversion $ROOTFS_FOLDER/usr/fwversion_ait
			sudo cp -f $CLOUDAPP_PATH/bin/AVAPIs_Server $ROOTFS_FOLDER/usr/cloud_daemon/AVAPIs_Server
			if [ "$DUAL_CPU_MD" = "yes" ]; then
				sudo cp -f $CLOUDAPP_PATH/bin/mdcapture_y_cpub $ROOTFS_FOLDER/usr/cloud_daemon
				sudo ln -s ./mdcapture_y_cpub $ROOTFS_FOLDER/usr/cloud_daemon/mdcapture_y
			fi
		else
			sudo cp -f fwversion $ROOTFS_FOLDER/usr/
			if [ "$ACTION_CAM" = "yes" ] && [ "$DUAL_CPU_MD" = "yes" ]; then
			sudo cp -f $CLOUDAPP_PATH/bin/mdcapture_y_cpub $ROOTFS_FOLDER/usr/cloud_daemon
			sudo ln -s ./mdcapture_y_cpub $ROOTFS_FOLDER/usr/cloud_daemon/mdcapture_y 
			fi
		fi
	fi
	sudo rm fwversion

#copy service app
    if [ -e $SERVICEAPP_PATH/bin ]; then
        for entry in  `ls $SERVICEAPP_PATH/bin` ; do

            if [ -e $USR_BIN/$entry ]; then
                cp -f $SERVICEAPP_PATH/bin/$entry $USR_BIN/$entry
                echo "update $entry into rootfs"
            fi
        done
    fi

#copy cgi
    if [ -e $CGI_PATH/bin ]; then
        cp -f $CGI_PATH/bin/CGI_PROCESS.sh $ROOTFS_FOLDER/usr/bin/
        cp -f $CGI_PATH/bin/Config.cgi $ROOTFS_FOLDER/var/webserver/www/cgi-bin/
        cp -f $CGI_PATH/bin/config2.bin $ROOTFS_FOLDER/usr/
        cp -f $CGI_PATH/bin/upload $ROOTFS_FOLDER/var/webserver/www/cgi-bin/
        cp -f $CGI_PATH/bin/miscellaneous $ROOTFS_FOLDER/var/webserver/www/cgi-bin/
        echo "update cgi into rootfs"
    fi
fi

echo ===========================
echo finish to setup application
