#!/bin/sh
#
# Start the video driver....
#
#echo "Enter AIT00VideoDrv shell script ..."
if [ -e /usr/modules/i2c-core.ko ] ; then
insmod /usr/modules/i2c-core.ko
fi
if [ -e /usr/modules/videodev.ko ] ; then
insmod /usr/modules/videodev.ko
fi
if [ -e /usr/modules/ait-cam-codec.ko ] ; then
insmod /usr/modules/ait-cam-codec.ko cpu_ipc=1 resv_dram_size=0x1800000 resv_dram_base=0x2400000
fi
