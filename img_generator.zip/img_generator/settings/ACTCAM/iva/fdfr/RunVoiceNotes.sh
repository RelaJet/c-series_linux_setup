#!/bin/sh
echo "Playing $1..."
cap_task=1
while [ $cap_task == 1 ]
do
  if [ "`pidof ffplay`" == ""  ]
  then
    cap_task=0 
  fi
  sleep 1
  echo "@"
done
ffplay -i $1 -f alsa hw:0,0 -loglevel error  < /dev/null &