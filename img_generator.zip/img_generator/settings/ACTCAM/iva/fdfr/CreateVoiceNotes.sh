#!/bin/sh
path=/mnt/mtd3/iva/fdfr
echo "Please speaking..."
if [ "$1" != "" ];then
  capture -t AAC  -b 32 -f 16000 -n 100 -loop 0  -recmode 1 -o $path/$1.aac
  if [ -f $path/$1.aac ]; then
    echo "$1:80:$path/$1.aac:$path/RunVoiceNotes.sh" >> $path/fr_voicenotes.conf
  fi
  sync
fi