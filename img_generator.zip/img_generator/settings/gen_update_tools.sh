#!/bin/bash

. ./config.mk 2> /dev/null

IMAGE=./image
BURN_IMAGE=./aitbootimage
CPUB_IMAGE=./cpub_image
CPUB_IPC_TARGET_IMAGE=./CPUB_RTOS_GCC_IPC/cpub_image
SPI_FOLDER=./settings/SPI
SD_FOLDER=./settings/SD
NAND_FOLDER=./settings/NAND
ACTCAM_FOLDER=./settings/ACTCAM
MDDR_TOOLS=./update_tools/mddr_update_tool
DDR3_TOOLS=./update_tools/ddr3_update_tool
ACTCAM_TOOLS=./update_tools/actcam_update_tool
WIFI_SRC=./root_file_system/etc/firmware
WIFI_NAME=$(cat ./root_file_system/etc/init.d/WIFIDEFINE)
WIFI_TYPE=$(cat ./root_file_system/etc/init.d/WIFITYPE)
IOT_FW=./driver/wifi/firmware/iot

#action cam update tool parm
if [ "$ACTION_CAM_RAW_KERNEL" = "yes" ]; then
    raw_kernel="_rawkernel"
    KERNEL_FILE_NAME="uImage.Raw"
else
    KERNEL_FILE_NAME="uImage"
fi
if [ "$ACTION_CAM_EMBEDDED_APP" != "" ]; then
    embedded_app="_embeddedapp"
fi

#clean update tools first
rm -rf $DDR3_TOOLS/*
rm -rf $MDDR_TOOLS/*
rm -rf $ACTCAM_TOOLS/*

#generate update tools 
case $1 in
EXT4)
    cp -f $SD_FOLDER/* $DDR3_TOOLS/
    cp -f $SD_FOLDER/* $MDDR_TOOLS/

    if [ -e $IMAGE/rootfs_ext4.img ]; then
        cp -f $IMAGE/rootfs_ext4.img $DDR3_TOOLS/
        cp -f $IMAGE/rootfs_ext4.img $MDDR_TOOLS/
    fi
    ;;
UBI)
    cp -f $NAND_FOLDER/* $DDR3_TOOLS/
    cp -f $NAND_FOLDER/* $MDDR_TOOLS/

    if [ -e $IMAGE/SdFwCode.bin ]; then
        cp -f $IMAGE/SdFwCode.bin $DDR3_TOOLS/
        cp -f $IMAGE/SdFwCode.bin $MDDR_TOOLS/
    fi

    if [ -e $IMAGE/U-boot.bin ]; then
        cp -f $IMAGE/U-boot.bin $DDR3_TOOLS/
        cp -f $IMAGE/U-boot.bin $MDDR_TOOLS/
    fi

    if [ -e $IMAGE/uImage ]; then
        cp -f $IMAGE/uImage $DDR3_TOOLS/
        cp -f $IMAGE/uImage $MDDR_TOOLS/
    fi

    if [ -e $IMAGE/rootfs_ubi.img ]; then
        cp -f $IMAGE/rootfs_ubi.img $DDR3_TOOLS/
        cp -f $IMAGE/rootfs_ubi.img $MDDR_TOOLS/
    fi
    ;;
CRAM | SQFS)
    if [ "$3" = "yes" ]; then
        echo "ActioCam use SD-card to burn image..."
        ACTION_CAM_SENSOR=$(cat ./root_file_system/etc/init.d/SENSOR)
        echo "RTOS built in sensor : $ACTION_CAM_SENSOR"
        if [ "$ACTION_CAM_SENSOR" = "" ]; then
           sensor_name=""
        else
           sensor_name="_"$ACTION_CAM_SENSOR
        fi
        
        if [ "$2" = "MDDR" ]; then
            if [ -d "$CPUB_IPC_TARGET_IMAGE/512M/" ]; then
                mkdir $CPUB_IMAGE/tmp
                cd $CPUB_IPC_TARGET_IMAGE;./FirmwarePackager.pl;cd -;
                cp -f $CPUB_IPC_TARGET_IMAGE/512M/MINIBOOT $CPUB_IMAGE/tmp/
                cp -f $CPUB_IPC_TARGET_IMAGE/512M/AITBOOT $CPUB_IMAGE/tmp/
                cp -f $CPUB_IPC_TARGET_IMAGE/512M/$ACTION_CAM_SENSOR/ALL $CPUB_IMAGE/tmp/
            fi

            if [ -e $CPUB_IMAGE/actioncam_rtos$sensor_name.bin ]; then
                cp -f $CPUB_IMAGE/actioncam_rtos$sensor_name.bin $ACTCAM_TOOLS/actioncam_rtos.bin
            fi

            #
            # delete extfs_oem
            #
            if [ -e $IMAGE/iva_sqfslzo.img ]; then
                rm $IMAGE/iva_sqfslzo.img
            fi
        else
            DDR_SIZE_LINE=`grep -n -F "DDR_SIZE=" ./config.mk`
            DDR_SIZE_NUM=`echo $DDR_SIZE_LINE | awk -F'"' '{print $2}'`
            DDR_SIZE_NUM=`echo $DDR_SIZE_NUM | awk -F'_' '{print $2}'`
            #echo "DRAM SIZE : $DDR_SIZE_NUM"
            if [ $DDR_SIZE_NUM -gt 128 ];then 
                if [ -d "$CPUB_IPC_TARGET_IMAGE/2G/" ]; then 
                    echo "use 2Gb RTOS fw for 8428G"
                    echo $ACTION_CAM_SENSOR
                    mkdir $CPUB_IMAGE/tmp
                    cd $CPUB_IPC_TARGET_IMAGE;./FirmwarePackager.pl;cd -;
                    cp -f $CPUB_IPC_TARGET_IMAGE/2G/MINIBOOT $CPUB_IMAGE/tmp/
                    cp -f $CPUB_IPC_TARGET_IMAGE/2G/AITBOOT $CPUB_IMAGE/tmp/
                    cp -f $CPUB_IPC_TARGET_IMAGE/2G/$ACTION_CAM_SENSOR/ALL $CPUB_IMAGE/tmp/
                fi
                # echo "DRAM is 2Gb"
                if [ -e $CPUB_IMAGE/actioncam_rtos_ddr3_2G$sensor_name.bin ]; then
                    cp -f $CPUB_IMAGE/actioncam_rtos_ddr3_2G$sensor_name.bin $ACTCAM_TOOLS/actioncam_rtos.bin
                else
                    echo "DDR3 configure as 2Gb,but no 2Gb RTOS fw"
                fi
            else
                if [ -d "$CPUB_IPC_TARGET_IMAGE/1G/" ]; then 
                    echo "use 1Gb RTOS fw for 8428Q"
                    echo $ACTION_CAM_SENSOR
                    mkdir $CPUB_IMAGE/tmp
                    cd $CPUB_IPC_TARGET_IMAGE;./FirmwarePackager.pl;cd -;
                    cp -f $CPUB_IPC_TARGET_IMAGE/1G/MINIBOOT $CPUB_IMAGE/tmp/
                    cp -f $CPUB_IPC_TARGET_IMAGE/1G/AITBOOT $CPUB_IMAGE/tmp/
                    cp -f $CPUB_IPC_TARGET_IMAGE/1G/$ACTION_CAM_SENSOR/ALL $CPUB_IMAGE/tmp/
                fi
                # echo "DRAM is 1Gb"
                if [ -e $CPUB_IMAGE/actioncam_rtos_ddr3_1G$sensor_name.bin ]; then
                    cp -f $CPUB_IMAGE/actioncam_rtos_ddr3_1G$sensor_name.bin $ACTCAM_TOOLS/actioncam_rtos.bin
                else
                    echo "DDR3 configure as 1Gb,but no 1Gb RTOS fw"
                fi
            fi
        fi

        cp -f $ACTCAM_FOLDER/* $ACTCAM_TOOLS/
        cp -f $BURN_IMAGE/SdFwCode.bin $ACTCAM_TOOLS/

        #
        # check iot wifi or not
        if [ "$WIFI_TYPE" != "iot" ];then
            rm -rf $ACTCAM_TOOLS/iot
        else
            #
            # cp IOT FW
            #
            cp -rf $IOT_FW $ACTCAM_TOOLS/   
        fi

        if [ "$ACTION_CAM_EMBEDDED_APP" != "" ]; then
            if [ -e $IMAGE/embedded_app.img ]; then
                cp -f $IMAGE/embedded_app.img $ACTCAM_TOOLS/
            fi
        else
            rm -f $ACTCAM_TOOLS/embedded_app.img
        fi

        echo "Using Updater$raw_kernel$embedded_app.txt as Updater.txt"
        mv -f $ACTCAM_TOOLS/Updater$raw_kernel$embedded_app.txt $ACTCAM_TOOLS/Updater.txt 
        rm -f $ACTCAM_TOOLS/Updater_*.txt

        if [ -e $IMAGE/mtd3_jffs2.img ]; then
            cp -f $IMAGE/mtd3_jffs2.img $ACTCAM_TOOLS/
        fi

        if [ -e $IMAGE/embedded_app.img ]; then
            cp -f $IMAGE/embedded_app.img $ACTCAM_TOOLS/embedded_app.img
            EMBEDDED_IMG_SIZE=$(wc -c <"$ACTCAM_TOOLS/embedded_app.img")
        fi
    fi
 
    cp -f $SPI_FOLDER/* $DDR3_TOOLS/
    cp -f $SPI_FOLDER/* $MDDR_TOOLS/

    if [ -e $IMAGE/SdFwCode.bin ]; then
        cp -f $IMAGE/SdFwCode.bin $DDR3_TOOLS/
        cp -f $IMAGE/SdFwCode.bin $MDDR_TOOLS/
    fi

    if [ -e $IMAGE/U-boot.bin ]; then
        cp -f $IMAGE/U-boot.bin $DDR3_TOOLS/
        cp -f $IMAGE/U-boot.bin $MDDR_TOOLS/
    fi

    if [ -e $IMAGE/uImage ]; then
        cp -f $IMAGE/uImage $DDR3_TOOLS/
        cp -f $IMAGE/uImage $MDDR_TOOLS/
        cp -f $IMAGE/uImage $ACTCAM_TOOLS/
    fi
    if [ -e $IMAGE/uImage.Raw ]; then
        cp -f $IMAGE/uImage.Raw $ACTCAM_TOOLS/
    fi
    if [ -e $IMAGE/rootfs_cram.img ]; then
        cp -f $IMAGE/rootfs_cram.img $DDR3_TOOLS/
        cp -f $IMAGE/rootfs_cram.img $MDDR_TOOLS/
        cp -f $IMAGE/rootfs_cram.img $ACTCAM_TOOLS/
        ROOTFS_IMG_SIZE=$(wc -c <"$ACTCAM_TOOLS/rootfs_cram.img")
    fi
    
    if [ -e $IMAGE/rootfs_cram1.img ]; then
        cp -f $IMAGE/rootfs_cram1.img $ACTCAM_TOOLS/
        ROOTFS1_IMG_SIZE=$(wc -c <"$ACTCAM_TOOLS/rootfs_cram1.img")
    fi

    if [ "$FD_FR_ROOTFS" = "no" ]; then
        echo "no FDFR enable, delete $ACTCAM_TOOLS/iva_sqfslzo.img"
        rm -f $ACTCAM_TOOLS/iva_sqfslzo.img
    else
        cp -f $IMAGE/iva_sqfslzo.img $ACTCAM_TOOLS/
    fi

    ;;
*)
    echo "ERROR: unknown file system type"
esac

#check file size
if [ "$3" = "yes" ]; then
    #action cam
    echo check download file size for Action SDK

    if [ -e $ACTCAM_TOOLS/$KERNEL_FILE_NAME ]; then
        KERNEL_IMG_SIZE=$(wc -c <"$ACTCAM_TOOLS/$KERNEL_FILE_NAME")
    else
        KERNEL_IMG_SIZE=0
    fi

    . ./settings/ACT_PARTITION/act_partiton$raw_kernel$embedded_app.config

    MTD_PART_NUM=1
    while [ "$MTD_PART_NUM" != "$TOTAL_PARTITION" ]
    do
        if [ "${P_NAME[$MTD_PART_NUM]}" = "kernel" ]; then
            SIZE=`echo ${P_SIZE[$MTD_PART_NUM]} | numfmt --from=iec`
            if [ $KERNEL_IMG_SIZE -gt $SIZE ]; then
                echo ERROR: kernel image size $KERNEL_IMG_SIZE \> $SIZE
                rm -rf $ACTCAM_TOOLS/*
                touch $ACTCAM_TOOLS/Kernel_image_size_error
                break
            else
                echo Kernel image size = $KERNEL_IMG_SIZE \(MAX = $SIZE\)
            fi
        fi

        if [ "${P_NAME[$MTD_PART_NUM]}" = "rootfs0" ]; then
            SIZE=`echo ${P_SIZE[$MTD_PART_NUM]} | numfmt --from=iec`
            if [ $ROOTFS_IMG_SIZE -gt $SIZE ]; then
                echo ERROR: rootfs0 image size $ROOTFS_IMG_SIZE \> $SIZE
                rm -rf $ACTCAM_TOOLS/*
                touch $ACTCAM_TOOLS/Rootfs0_image_size_error
                break
            else
                echo rootfs image size = $ROOTFS_IMG_SIZE \(MAX = $SIZE\)
            fi
        fi

        if [ "${P_NAME[$MTD_PART_NUM]}" = "rootfs1" ]; then
            SIZE=`echo ${P_SIZE[$MTD_PART_NUM]} | numfmt --from=iec`
            if [ $ROOTFS1_IMG_SIZE -gt $SIZE ]; then
                echo ERROR: rootfs1 image size $ROOTFS1_IMG_SIZE \> $SIZE
                rm -rf $ACTCAM_TOOLS/*
                touch $ACTCAM_TOOLS/Rootfs1_image_size_error
                break
            else
                echo rootfs0 image size = $ROOTFS1_IMG_SIZE \(MAX = $SIZE\)
            fi
        fi

        if [ "${P_NAME[$MTD_PART_NUM]}" = "embedded" ]; then
            SIZE=`echo ${P_SIZE[$MTD_PART_NUM]} | numfmt --from=iec`
            if [ $EMBEDDED_IMG_SIZE -gt $SIZE ]; then
                echo ERROR: embedded image size $EMBEDDED_IMG_SIZE \> $SIZE
                rm -rf $ACTCAM_TOOLS/*
                touch $ACTCAM_TOOLS/Embedded_image_size_error
                break
            else
                echo embedded image size = $EMBEDDED_IMG_SIZE \(MAX = $SIZE\)
            fi
        fi
        MTD_PART_NUM=$(($MTD_PART_NUM+1))
    done

else
    #normal cloud drone cam
    echo check download file size for Normal SDK
fi
