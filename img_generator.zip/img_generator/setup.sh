#!/bin/sh
#show SDK verision
if [ -d svn_log ] ; then
echo "Show SDK information"
echo "----------------"
for i in `ls svn_log`
do
Revision=`grep "Last Changed Rev" svn_log/$i`
Revision=`echo $Revision | awk -F": " '{print $2}'`
echo "The ${i%_svn} revision is $Revision"
done
echo "----------------\n"
else
echo "WARNING: Can't get SDK version"
fi

if [ $# -ge 1 ]; then
	if [ -e ./settings/config/$1 ]; then
    	cp -f ./settings/config/$1 ./config.mk
		sync
	fi
else
	echo Please choice one of the following configure
	echo "----------------"
	for i in `ls settings/config`
	do
		echo $i
	done
	echo "----------------"
	echo "\nExample: ./setup.sh normal_config"
fi
