/usr/bin/brcm_patchram_plus -d --enable_hci --no2bytes --tosleep 200000 --baudrate 115200 --patchram /etc/firmware/bcm40183b2.hcd /dev/ttyS3 &
