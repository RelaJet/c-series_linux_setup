echo "43" > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio43/direction
echo "0" > /sys/class/gpio/gpio43/value
#sleep 1
echo "1" > /sys/class/gpio/gpio43/value
echo "43" > /sys/class/gpio/unexport
