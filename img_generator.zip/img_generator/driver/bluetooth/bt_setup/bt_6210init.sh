/usr/bin/brcm_patchram_plus -d --enable_hci --no2bytes --tosleep 200000 --baudrate 115200 --patchram /etc/firmware/bcm20710a1.hcd /dev/ttyS3 &
