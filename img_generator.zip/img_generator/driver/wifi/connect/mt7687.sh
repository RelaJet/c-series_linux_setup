#!/bin/sh
#
# blink PWM0 for connection
#
/etc/init.d/WaitLinkReady.sh
link=$(cat /tmp/linkstatus)

if [ $link != 1 ];then
  echo "WIFI disconnected..."
#  . /etc/init.d/LogTime.sh "connectap.s"
#  
#  iotinfo=/tmp/.iotinfo
#  
#  . /etc/init.d/SetPWM.sh 0 1 50
#  nolink=""
#  #
#  # 80 -> CC3200 get ip-address
#  # 04 -> CC3200 connect to ap
#  good="84"
#  status=""
#  ip="0.0.0.0"
#  #
#  # increase to 15 secs for timeout
#  #
#  loglevel=4 
#  #$(cat /proc/sys/kernel/printk | awk -F" " '{ print $1}')
#  #echo 7 > /proc/sys/kernel/printk
#  try_cnt=100
#  goodcnt=0
#  
#  while [ $try_cnt -gt 0 ] && [ "$status" != "$good" ]
#  do
#    echo "Connecting..."
#    iot-tool -i > $iotinfo
#    status=$(grep "Status" $iotinfo | awk -F"x" '{ print $2 }')
#    if [ "$status" != "$good" ];then
#       sleep 5
#    fi  
#    try_cnt=`expr $try_cnt - 1`
#    goodcnt=`expr $goodcnt + 1`
#  done
#    
#  if [ "$status" = "$good"  ];then
#    my_router=`ip route |cut -d' ' -f 1 | sed 's/.0\/24/.1/g' | tail -n 1`
#    ip=`ifconfig | grep "Bcast" | awk -F":" '{ print $2 }' | awk -F" " '{ print $1 }'`
#    /sbin/route add default gw $my_router
#    echo "Reconnect net:up"
#    . /etc/init.d/SetPWM.sh 0 1000 50
#    echo 1 > /tmp/.iot_status
#    echo 1 > /tmp/linkstatus
#  else
#    echo 0 > /tmp/.iot_status
#    echo 0 > /tmp/linkstatus
#    echo "Reconnect $goodcnt failed, net:down"
#    echo "Power off Camera"
#    . /etc/init.d/SetPWM.sh 0 3 20
#    . /etc/init.d/PowerOff.sh
#  fi
#  echo "$ip" > /tmp/linkip  
#  echo $loglevel > /proc/sys/kernel/printk
#  . /etc/init.d/LogTime.sh "connectap.e"
#  sync
fi