#!/bin/sh
echo "ap6212a early notify disabled"
dhd_priv wl earlynotify 0

