#!/bin/sh
#
# blink PWM0 for connection
#
/etc/init.d/WaitLinkReady.sh
link=$(cat /tmp/linkstatus)

if [ $link != 1 ];then 
  echo "WIFI disconnected...."
#  . /etc/init.d/LogTime.sh "connectap.s"
#  
#  iotinfo=/tmp/.iotinfo
#  
#  . /etc/init.d/SetPWM.sh 0 1 50
#  nolink=""
#  #
#  # 80 -> CC3200 get ip-address
#  # 04 -> CC3200 connect to ap
#  good="84"
#  status=""
#  coldup_ip="0.0.0.0"
#  #
#  # increase to 15 secs for timeout
#  #
#  loglevel=4 
#  #$(cat /proc/sys/kernel/printk | awk -F" " '{ print $1}')
#  #echo 7 > /proc/sys/kernel/printk
#  try_cnt=100
#  goodcnt=0
#  ip="0.0.0.0"
#  #
#  # Set ip/mac first
#  #
#  new_ssid=$(cfgparser -s wifi -i ssid -t s)
#  new_psk=$(cfgparser -s wifi -i psk -t s)
#  new_auth=$(cfgparser -s wifi -i auth -t i)
#  
#  iot-tool -s $new_ssid -a $new_auth -p $new_psk
#  
#  while [ $try_cnt -gt 0 ] && [ "$status" != "$good" ]
#  do
#    echo "Connecting..."
#    if [ "$status" != "$good" ];then
#       sleep 5
#    fi  
#    iot-tool -i > $iotinfo
#    #ip=$(grep "IP Address" $iotinfo | awk -F" " '{ print $3 }')
#    status=$(grep "Status" $iotinfo | awk -F"x" '{ print $2 }')
#    
#    try_cnt=`expr $try_cnt - 1`
#    goodcnt=`expr $goodcnt + 1`
#  
#  done
#    
#  if [ "$status" = "$good"  ];then
#    ip=$(grep "IP Address" $iotinfo | awk -F" " '{ print $3 }')
#    mac=$(grep "MAC:" $iotinfo | awk -F" " '{ print $2 }')
#    ifconfig eth0 hw ether $mac
#    ifconfig eth0 $ip
#    my_router=`ip route |cut -d' ' -f 1 | sed 's/.0\/24/.1/g' | tail -n 1`
#    /sbin/route add default gw $my_router
#    echo "Reconnect net:up"
#    . /etc/init.d/SetPWM.sh 0 1000 50
#    echo 1 > /tmp/.iot_status
#    echo 1 > /tmp/linkstatus
#    echo "$ip" > /tmp/linkip
#  else
#    echo 0 > /tmp/.iot_status
#    echo 0 > /tmp/linkstatus
#    echo "Reconnect $goodcnt failed, net:down"
#    echo "Power off Camera"
#    . /etc/init.d/SetPWM.sh 0 3 20
#    . /etc/init.d/PowerOff.sh
#  fi
#  echo $loglevel > /proc/sys/kernel/printk
#  . /etc/init.d/LogTime.sh "connectap.e"

fi