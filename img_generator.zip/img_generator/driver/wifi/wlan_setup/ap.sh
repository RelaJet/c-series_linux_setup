#!/bin/sh
echo "Launch Broadcom AP Mode in /usr/wireless/ap.sh..."
case "$1" in
	start)
    	insmod  /usr/modules/bcmdhd.ko
	wifi_device_id=`cat /sys/bus/sdio/devices/mmc2:0001:2/device`
	if [ "$wifi_device_id" = "0xa962" ]; then
		echo "Detected AP6181/AP6210 wireless module."
		echo -n "/etc/firmware/fw_bcm40181a2_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
	elif [ "$wifi_device_id" = "0xa9a6" ]; then
		echo "Detected AP6212A wireless module."
		echo -n "/etc/firmware/fw_bcm43438a1_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
	elif [ "$wifi_device_id" = "0x4334" ]; then
		echo "Detected AP6233F wireless module."
		echo -n "/etc/firmware/fw_bcm4334b1_ag_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
	elif [ "$wifi_device_id" = "0x4330" ]; then
		echo "Detected AP6330 wireless module."
		echo -n "/etc/firmware/fw_bcm40183b2_ag_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
	else
		echo "ERROR: Unknown wireless module. (need Manually)"
		exit 1
	fi
    	ap_conf.sh

		MODE="`nvconf get wireless.ap.mode`"
		if [ "$MODE" = "b" ] || [ "$MODE" = "g" ] ;then
      			ifconfig wlan0 up
			wl down
			wl nmode 0
			if [ "$MODE" = "b" ] ;then
				wl gmode LegacyB
			fi
			wl up
		fi

		touch  /var/lib/misc/udhcpd.leases
		DEBUG="`nvconf get system.debug_mode`"
		if [ "$DEBUG" = "yes" ] ;then
			/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd -e /mnt/mtd3/entropy.bin &
		else
			/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -e /mnt/mtd3/entropy.bin &
		fi

		IPADDR="`nvconf get wireless.ap.ipaddr`"
		SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
		ifconfig wlan0 $IPADDR netmask $SUBNETMASK
		udhcpd -S /mnt/mtd3/udhcpd-ap.conf&
	;;
	stop)
		echo " Kill all process of AP Mode"
		rmmod  bcmdhd
		killall udhcpd
		killall hostapd
	;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
esac

exit $?
