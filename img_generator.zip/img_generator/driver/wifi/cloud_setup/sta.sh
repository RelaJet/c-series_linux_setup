#!/bin/sh
###################
#Wifi station mode#
###################

echo "Launch AP/STA Mode in sta.sh..."

wifistatus=`wpa_cli status`
#WIFI_MODULE=`nvconf get WIFI.MODULE`
WIFIDRIVER_PATH=/usr/wireless
WIFIMODULE=`cat /tmp/WIFIMODULE`
if [ "$WIFIMODULE" = "ap6181"  ]
then
        WIFI_MODULE=bcm_wlan
else
        WIFI_MODULE=wlan
fi

case "$1" in
start)
#	echo "Auto Mode..."
	wifi_device_id=`cat /sys/bus/sdio/devices/mmc2:0001:2/device`
        if [ "$wifi_device_id" = "0xa962" ]; then
                echo "Detected AP6181/AP6210 wireless module."
                echo -n "/etc/firmware/fw_bcm40181a2.bin">/sys/module/bcmdhd/parameters/firmware_path
        elif [ "$wifi_device_id" = "0xa9a6" ]; then
                echo "Detected AP6212A wireless module."
                echo -n "/etc/firmware/fw_bcm43438a1.bin">/sys/module/bcmdhd/parameters/firmware_path
        elif [ "$wifi_device_id" = "0x4334" ]; then
                echo "Detected AP6233F wireless module."
                echo -n "/etc/firmware/fw_bcm4334b1_ag.bin">/sys/module/bcmdhd/parameters/firmware_path
        elif [ "$wifi_device_id" = "0x4330" ]; then
                echo "Detected AP6330 wireless module."
                echo -n "/etc/firmware/fw_bcm40183b2_ag.bin">/sys/module/bcmdhd/parameters/firmware_path
        else
                echo "ERROR: Unknown wireless module. (need Manually)"
                exit 1
        fi

	nvconf set SETTING_MODE 0
	sleep 1
	WIFIMODE="`nvconf get wireless.ap.sta.switch`"
	test -f /mnt/mtd3/wpa_supplicant.conf
	if [ "$WIFIMODE" = "3" ]
	then
		echo "Auto Mode..."
		if [ $? = 0 ]
		then
			if [ "$WIFI_MODULE" = "bcm_wlan" ]
        		then
				wpa_supplicant -Dnl80211 -iwlan0 -c/mnt/mtd3/wpa_supplicant.conf -B
			else
				wpa_supplicant -Dwext -iwlan0 -c/mnt/mtd3/wpa_supplicant.conf -B
			fi
			udhcpc -iwlan0 -b

			i=0
			for i in $(seq 1 10)
			do
				if (wpa_cli -iwlan0 status|grep -q "^wpa_state=COMPLETED")
				then
					break
				fi
				echo "Network status checking..."
				sleep 1
				i=`expr $i + 1`
			done
    
			if (wpa_cli -iwlan0 status|grep -q "^wpa_state=COMPLETED")
			then
				echo "network is ok"
				#LedCtrl WIFI 1 
				/usr/bin/run_goahead.sh &
			else
				echo "network is down"
				echo "Launch AP mode for wifi setting"
	   			#For wifi setting
				killall wpa_supplicant 
				killall udhcpc
				/usr/wireless/ap.sh start
				#if [ "$WIFI_MODULE" = "bcm_wlan" ]
	                        #then
		   		#	/usr/ap6181/ap.sh start
				#else
				#	/usr/mt5931/ap.sh start
				#fi
				#IPAddr=`ifconfig wlan0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1 }'`
	   			#goahead -v  --home /etc/goahead_conf/ /var/webserver/www $IPAddr:80 &
				LedCtrl WIFI 2 50 50
                		LedCtrl POWER 0
                		/usr/bin/run_goahead.sh &
			fi
		else
			/usr/wireless/ap.sh start
			#if [ "$WIFI_MODULE" = "bcm_wlan" ]
                	#then
				#/usr/ap6181/ap.sh start
			#else
				#/usr/mt5931/ap.sh start
			#fi
			#For wifi setting	
			#IPAddr=`ifconfig wlan0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1 }'`
			#goahead -v  --home /etc/goahead_conf/ /var/webserver/www $IPAddr:80 &
			#echo "" >/dev/null &
			LedCtrl WIFI 2 50 50
                	LedCtrl POWER 0
                	/usr/bin/run_goahead.sh &
		fi
	elif [ "$WIFIMODE" = "2" ]
	then
		echo "Force STA mode..."
		if [ "$WIFI_MODULE" = "bcm_wlan" ]
        	then
			wpa_supplicant -Dnl80211 -iwlan0 -c/mnt/mtd3/wpa_supplicant.conf -B
		else
			wpa_supplicant -Dwext -iwlan0 -c/mnt/mtd3/wpa_supplicant.conf -B
		fi
		udhcpc -iwlan0 -b
		/usr/bin/run_goahead.sh &
	elif [ "$WIFIMODE" = "1" ]
	then
		echo "Force AP mode..."
		/usr/wireless/ap.sh start
		#if [ "$WIFI_MODULE" = "bcm_wlan" ]
                #then
		#	/usr/ap6181/ap.sh start
		#else
			#/usr/mt5931/ap.sh start
		#fi
		#IPAddr=`ifconfig wlan0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1 }'`
		#goahead -v  --home /etc/goahead_conf/ /var/webserver/www $IPAddr:80 &
		LedCtrl WIFI 2 50 50
		LedCtrl POWER 0
		/usr/bin/run_goahead.sh &
	fi
	#this ping script
	#ping=`ping 8.8.8.8 -c 5`
	;;
stop)
	echo "Kill all process of STA Mode"
	KilltoDead wpa_supplicant
	KilltoDead udhcpc
	nvconf set SETTING_MODE 1
	ifconfig wlan0 down
	LedCtrl WIFI 0
	;;
*)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

