#!/bin/sh
echo "Launch Cooee Mode in /usr/ap6181/cooee.sh..."
#WIFI_MODULE=`nvconf get WIFI.MODULE`
WIFIDRIVER_PATH=/usr/ap6181
test -d $WIFIDRIVER_PATH
if [ $? == 1 ]
then
        echo "NO folder $WIFIDRIVER_PATH ..."
        #WIFIMODULE=mt5931
        WIFIMODULE=`cat /tmp/WIFIMODULE`
else
        WIFIMODULE=ap6181
fi
if [ "$WIFIMODULE" = "ap6181"  ]
then
        WIFI_MODULE=bcm_wlan
else
        WIFI_MODULE=wlan
fi
case "$1" in
 	start)
		if [ "$WIFI_MODULE" = "bcm_wlan" ]
                then
			/usr/ap6181/sta.sh stop &
			/usr/ap6181/ap.sh stop &
		fi
		if [ "$WIFI_MODULE" = "bcm_wlan" ]
        	then
			echo -n "/etc/firmware/fw_bcmdhd_Cooee.bin">/sys/module/bcm_wlan/parameters/firmware_path
		fi
		sleep 1
		IPADDR="`nvconf get wireless.ap.ipaddr`"
		SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
		sleep 1
		LedCtrl WIFI 2 50 50
		ifconfig wlan0 $IPADDR netmask $SUBNETMASK 
		/usr/ap6181/easysetup -p 1 > /tmp/wifieasysetup
		#EASYSSID=`cat /tmp/wifieasysetup |awk 'NR==2{print $2}'`
		EASYSSID=`cat /tmp/wifieasysetup |awk 'NR==2' | cut -d':' -f 2`
		#EASYPWD=`cat /tmp/wifieasysetup |awk 'NR==3{print $2}'`
		EASYPWD=`cat /tmp/wifieasysetup |awk 'NR==3' | cut -d':' -f 2`
		Timeout=`cat /tmp/wifieasysetup |awk 'NR==2'`
		if [ "$EASYSSID" == "" ] || [ "$Timeout" == "easy setup query timed out." ]
		then
			echo "WIFI SSID is NULL"	
		else
			nvconf set wireless.sta.ssid "$EASYSSID"
			PlayWave /usr/bin/be.wav
		fi
		if [ "$EASYPWD" == "" ]
		then
			echo "WIFI PASSWORD is NULL"
		else
			nvconf set wireless.sta.psk "$EASYPWD"
			PlayWave /usr/bin/be.wav
		fi
		sync
		select_sleep 1
		if [ "$EASYSSID" == "" ]
		then
			echo "cat't get ssid"
		else
			/usr/bin/wifiset.sh "$EASYSSID" "$EASYPWD"
		fi
		sync
		#PlayWave /usr/bin/be.wav
		reboot.sh
		;;
	stop)
		echo " Kill all process of Cooee Mode"
		killall easysetup
		LedCtrl WIFI 0
		;;
	*)
		echo "Usage: $0 {start|stop}"
		exit 1
esac

exit $?

