#!/bin/sh
wl down
wl band b
wl mpc 0

#wl nrate -m 54
wl nrate -m 7
wl rateset 54b
wl country ALL
wl up
wl channel 1
wl txpwr1 -1
wl pkteng_start 00:11:22:33:44:55 tx 30 1024 0
wl phy_forcecal 1
