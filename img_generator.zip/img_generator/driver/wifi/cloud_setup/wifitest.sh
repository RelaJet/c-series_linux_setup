#!/bin/sh
killall monitor_clouddemon
/usr/cloud_daemon/CloudDaemon stop
/usr/wireless/sta.sh stop
/usr/wireless/ap.sh stop
echo -n "/etc/firmware/ap6181/fw_bcm40181a2_mfg.bin">/sys/module/bcm_wlan/parameters/firmware_path
ifconfig wlan0 192.168.1.1 netmask 255.255.255.0

