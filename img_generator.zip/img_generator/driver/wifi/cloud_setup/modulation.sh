#!/bin/sh                                                           
if [ "$1" == "h" ]||[ "$1" == "help" ]||[ "$1" == "" ]; then
echo ""
echo "*********Modulation**********"
echo "Parameter 1: mode"
echo "Parameter 2: data rate"
echo "Parameter 3: channel"
echo "Parameter 4: power"
echo "*****************************"
echo ""
exit 0
fi
mode=$1
data_rate=$2
channel=$3
power=$4


wl down
echo "wl down"
if [ "$mode" == "a" ]; then
wl band a
echo "wl band a"
else
wl band b
echo "wl band b"
fi
wl mpc 0
echo "wl mpc 0"
if [ "$mode" == "n" ]; then
wl nrate -m $data_rate #Data rate
echo "wl nrate -m $data_rate"
wl rateset 54b
echo "wl rateset 54b"
else
wl nrate -r $data_rate
echo "wl nrate -r $data_rate"
wl rateset ${data_rate}b
echo "wl rateset ${data_rate}b"
fi
wl country ALL
echo "wl country ALL"
wl up
echo "wl up"
wl channel $channel
echo "wl channel $channel"
if [ "$power" == "auto" ]; then
wl txpwr1 -1
echo "wl txpwr1 -1"
else
wl txpwr1 -q $power
echo "wl txpwr1 -q $power"
fi
wl pkteng_start 00:11:22:33:44:55 tx 30 1024 0
echo "wl pkteng_start 00:11:22:33:44:55 tx 30 1024 0"
wl phy_forcecal 1
echo "wl phy_forcecal 1"
