#!/bin/sh
echo "Launch AP Mode in /usr/wireless/ap.sh..."
#WIFI_MODULE=`nvconf get WIFI.MODULE`
WIFIDRIVER_PATH=/usr/wireless
WIFIMODULE=`cat /tmp/WIFIMODULE`
WIFIDEFINE=`cat /etc/init.d/WIFIDEFINE`
if [ "$WIFIMODULE" = "ap6181"  ]
then
        WIFI_MODULE=bcm_wlan
else
        WIFI_MODULE=wlan
fi
case "$1" in
 	start)
		#if [ "$WIFI_MODULE" = "bcm_wlan" ]
                #then
		#	/usr/wireless/sta.sh stop
		#else
		#	/usr/mt5931/sta.sh stop &
		#	insmod /usr/modules/mt5931_p2p.ko mode=1
		#fi
		/usr/wireless/sta.sh stop
		if [ "$WIFI_MODULE" = "bcm_wlan" ]
		then
			/usr/bin/ap_conf.sh
		else
			/usr/bin/ap_conf_rtl.sh
		fi
		nvconf set SETTING_MODE 1

		if [ "$WIFI_MODULE" = "bcm_wlan" ]
		then
			wifi_device_id=`cat /sys/bus/sdio/devices/mmc2:0001:2/device`
			if [ "$wifi_device_id" = "0xa962" ]; then
				echo "Detected AP6181/AP6210 wireless module."
				echo -n "/etc/firmware/fw_bcm40181a2_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
			elif [ "$wifi_device_id" = "0xa9a6" ]; then
				echo "Detected AP6212A wireless module."
				echo -n "/etc/firmware/fw_bcm43438a1_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
			elif [ "$wifi_device_id" = "0x4334" ]; then
				echo "Detected AP6233F wireless module."
				echo -n "/etc/firmware/fw_bcm4334b1_ag_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
			elif [ "$wifi_device_id" = "0x4330" ]; then
				echo "Detected AP6330 wireless module."
				echo -n "/etc/firmware/fw_bcm40183b2_ag_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
			else
				echo "ERROR: Unknown wireless module. (need Manually)"
				exit 1
			fi
		fi
		##if [ "$WIFI_MODULE" = "bcm_wlan" ]
        	##then
			#echo -n "/etc/firmware/ap6181_old/fw_bcm40181a2.bin">/sys/module/bcm_wlan/parameters/firmware_path
			#echo -n "/etc/firmware/fw_bcmdhd_ap.bin">/sys/module/bcm_wlan/parameters/firmware_path
			#echo -n "/etc/firmware/fw_bcmdhd_apsta.bin">/sys/module/bcm_wlan/parameters/firmware_path
			##echo -n "/etc/firmware/fw_bcmdhd_apsta.bin">/sys/module/bcmdhd/parameters/firmware_path
			##sync
		#else    
		#	/mnt/sdcard/wifisetting.sh
		#	exit 1
		##fi
		#insmod  /usr/modules/bcm_wlan_ap6181.ko 

		sleep 1

		touch  /var/lib/misc/udhcpd.leases
		hostapd /mnt/mtd3/hostapd.conf -dd &

		IPADDR="`nvconf get wireless.ap.ipaddr`"
		SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
		sleep 1
		if [ $WIFIDEFINE == "rtl8189es"  ]
		then
			ifconfig wlan1 $IPADDR netmask $SUBNETMASK
		else
			ifconfig wlan0 $IPADDR netmask $SUBNETMASK 
		fi
		sleep 1
		udhcpd -S /mnt/mtd3/udhcpd-ap.conf&
		LedCtrl WIFI 2 50 50
		sleep 1
		;;
	stop)
		#rmmod ap0
		echo " Kill all process of AP Mode"
#		kill $(ps aux | grep 'udhcpd' | awk '{print $1}')
#		kill $(ps aux | grep 'hostapd' | awk '{print $1}')
		KilltoDead udhcpd
		KilltoDead hostapd
		nvconf set SETTING_MODE 0
		ifconfig wlan0 down
		LedCtrl WIFI 0
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
esac

exit $?

