#!/bin/sh
echo "Launch Realtek RTL8189ES AP Mode ..."

case "$1" in
  start)
	insmod /usr/modules/8189es.ko
	sleep 1
	ap_conf_rtl.sh
	touch  /var/lib/misc/udhcpd.leases
	/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd &

	IPADDR="`nvconf get wireless.ap.ipaddr`"
	SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
	sleep 1
	ifconfig wlan1 $IPADDR netmask $SUBNETMASK
	sleep 1
	udhcpd -S /mnt/mtd3/udhcpd-ap.conf &
;;
  stop)
	echo " Kill all process of AP Mode"
	killall udhcpd
	killall hostapd
	rmmod 8189es
;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

