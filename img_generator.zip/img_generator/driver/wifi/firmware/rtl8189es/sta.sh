#!/bin/sh
echo "Launch Realtek STA Mode in" ${PWD} "/sta.sh..."

if [ "$1" = "" ];then

if [ -e /usr/modules/8189es.ko ];then
insmod  /usr/modules/8189es.ko
sleep 1
fi 

fi

if [ "$2" = "" ];then
wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -B
#wpa_supplicant -Dwext -iwlan0 -c/etc/wpa_supplicant.conf -B
udhcpc -iwlan0 -b
else
echo "Quick link $2 to $1"
ifconfig wlan0 $2
wl band b
wl join $1
fi


