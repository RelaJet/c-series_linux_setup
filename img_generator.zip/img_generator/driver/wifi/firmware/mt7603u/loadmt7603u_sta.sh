#!/bin/sh
echo "Launch MTK STA Mode in" ${PWD} "/sta.sh..."
. /usr/bin/DEFINE.sh
SCAN_FILE=/tmp/scanlist.txt

#if [ "$1" = "" ];then
if [ -e /usr/modules/mt7603u_ap.ko ];then
	insmod /usr/modules/prealloc.ko
	insmod /usr/modules/mt7603u_ap.ko
	sleep 1
fi 
#fi

#if [ "$2" = "" ];then
ifconfig ra0 up
sleep 1
ifconfig apcli0 up
sleep 1

#Scan
iwpriv apcli0 set SiteSurvey=1
iwpriv apcli0 get_site_survey > $SCAN_FILE

SSID=`$NV_GET wireless.sta.ssid`
PSK=`$NV_GET wireless.wpa.psk`
#AUTH = #OPEN/WPA2PSK/WPAPSK
#ENCRYTYPE = #NONE/AES/TKIP

#Parse SSID for Auth, EncryType & number of channel
SECURITY=`grep "$SSID" $SCAN_FILE | awk 'NR==1 {print $4}'`
AUTH=`echo $SECURITY | cut -d'/' -f 1`
ENCRYTYPE=`echo $SECURITY | cut -d'/' -f 2`
CHANNEL=`grep "$SSID" $SCAN_FILE | awk 'NR==1 {print $1}'`

#Setup channel
iwpriv apcli0 set Channel=$CHANNEL

#Open mode AP setup
iwpriv apcli0 set ApCliEnable=0
iwpriv apcli0 set ApCliAuthMode=$AUTH
iwpriv apcli0 set ApCliEncrypType=$ENCRYTYPE
iwpriv apcli0 set ApCliSsid=$SSID
iwpriv apcli0 set ApCliWPAPSK=$PSK
iwpriv apcli0 set ApCliEnable=1

#wpa_supplicant -Dwext -ira0 -c/etc/wpa_supplicant.conf -B
udhcpc -iapcli0 -b
#else
#echo "Quick link $2 to $1"
#ifconfig wlan0 $2
#wl band b
#wl join $1
#fi
