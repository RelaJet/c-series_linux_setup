#!/bin/sh
echo "Launch Broadcom STA Mode in" ${PWD} "/sta.sh..."

if [ "$1" = "" ];then
	insmod /usr/modules/mtprealloc.ko
	insmod /usr/modules/mt7603u_sta.ko
	sleep 1
fi

if [ "$2" = "" ];then
	wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -B
	udhcpc -iwlan0 -b
else
	echo "Quick link $2 to $1"
	ifconfig wlan0 $2
fi


