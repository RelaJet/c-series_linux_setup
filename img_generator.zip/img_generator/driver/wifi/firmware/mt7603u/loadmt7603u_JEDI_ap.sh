#!/bin/sh
echo "Launch Broadcom AP Mode in /usr/wireless/ap.sh..."
case "$1" in
	start)
		insmod /usr/modules/mtprealloc.ko
		insmod /usr/modules/mt7603u_sta.ko    	
    		ap_conf.sh

		MODE="`nvconf get wireless.ap.mode`"
		if [ "$MODE" = "b" ] || [ "$MODE" = "g" ] ;then
      			ifconfig wlan0 up
			wl down
			wl nmode 0
			if [ "$MODE" = "b" ] ;then
				wl gmode LegacyB
			fi
			wl up
		fi

		touch  /var/lib/misc/udhcpd.leases
		DEBUG="`nvconf get system.debug_mode`"
		if [ "$DEBUG" = "yes" ] ;then
			/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd -e /mnt/mtd3/entropy.bin &
		else
			/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -e /mnt/mtd3/entropy.bin &
		fi

		IPADDR="`nvconf get wireless.ap.ipaddr`"
		SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
		ifconfig wlan0 $IPADDR netmask $SUBNETMASK
		udhcpd -S /mnt/mtd3/udhcpd-ap.conf&
	;;
	stop)
		echo " Kill all process of AP Mode"
		rmmod  bcmdhd
		killall udhcpd
		killall hostapd
	;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
esac

exit $?
