#!/bin/sh
echo "Launch AR1021 AP Mode in /usr/wireless/ap.sh..."
case "$1" in
	start)
		insmod /usr/modules/compat.ko
		insmod /usr/modules/cfg80211.ko
		insmod /usr/modules/ath6kl_usb.ko ath6kl_p2p=0x0 debug_quirks=0x200
						#ath6kl_p2p=0x19 for enable P2P
    		ap_conf.sh
		#MODE="`nvconf get wireless.ap.mode`"
		#if [ "$MODE" = "b" ] || [ "$MODE" = "g" ] ;then
      		#	ifconfig wlan0 up
		#	wl down
		#	wl nmode 0
		#	if [ "$MODE" = "b" ] ;then
		#		wl gmode LegacyB
		#	fi
		#	wl up
		#fi

		touch  /var/lib/misc/udhcpd.leases
		DEBUG="`nvconf get system.debug_mode`"
		if [ "$DEBUG" = "yes" ] ;then
			/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd -e /mnt/mtd3/entropy.bin &
		else
			/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -e /mnt/mtd3/entropy.bin &
		fi

		IPADDR="`nvconf get wireless.ap.ipaddr`"
		SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
		ifconfig wlan0 $IPADDR netmask $SUBNETMASK
		udhcpd -S /mnt/mtd3/udhcpd-ap.conf&
	;;
	stop)
		echo " Kill all process of AP Mode"
		rmmod ath6kl_usb
		rmmod cfg80211
		rmmod compat
		killall udhcpd
		killall hostapd
	;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
esac

exit $?
