
BCM43438 Ultra Low Power mode Porting Guide

Reversion: SVN35847
Config: ait6366g_bcm43438_defconfig
FW: http://svn-sw/svn/SmartCamera/LinuxKernel/trunk/MCRV2_SDK/driver/wifi/firmware/BCM43438a1/43430r1_swoob1.bin

Sleep command:
http://svn-sw/svn/SmartCamera/LinuxKernel/trunk/MCRV2_SDK/driver/wifi/firmware/BCM43438a1/bcmsleep.sh

Test flow:
1. Put files in the following path to sd card.
http://svn-sw/svn/SmartCamera/LinuxKernel/trunk/MCRV2_SDK/driver/wifi/firmware/BCM43438a1

2. Linux boot will insert bcm43438 driver.

3. Connect to AP and request an IP.
ifconfig wlan0 up 
./wl join YOUR_AP_SSID
udhcpc -iwlan0 -b

4. Use another PC to ping the IP which is required in step 3. Or use the following command to add the IP and MAC to ARP table:
EX: sudo arp -s 192.168.11.23 11:22:33:44:55:66

4. Sleep
Execute sleep shell script:
bcmsleep.sh 

5. Use remote wakeup program, udp_send , to wakeup AIT8328.
Source path:
http://svn-sw/svn/SmartCamera/LinuxKernel/trunk/MCRV2_SDK/driver/wifi/firmware/BCM43438a1/udp_send.c
example:
udp_send 192.168.11.23 8000

