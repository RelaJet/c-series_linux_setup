#!/bin/sh
. /etc/init.d/LogTime.sh "sta.s"
ifconfig wlan0 up
try_cnt=80
ip="0.0.0.0"
iotinfo=/tmp/.iotinfo
. /etc/init.d/SetPWM.sh 0 1 50
while [ $try_cnt -gt 0 ] &&  [ "$ip" = "0.0.0.0" ] 
do
  dhd_priv dhcpc_dump > $iotinfo
  ip=$(grep "ipaddr" /tmp/.iotinfo | awk -F" " '{ print $2 }')
  try_cnt=`expr $try_cnt - 1`
  if [ "$ip" = "0.0.0.0" ];then
    usleep 100000
  fi
done
if [ "$ip" != "0.0.0.0" ] ;then
  ifconfig wlan0 $ip
  my_router=$(grep "ipaddr" /tmp/.iotinfo | awk -F" " '{ print $2 }')
  /sbin/route add default gw $my_router

  echo 1 > /tmp/.iot_status
  echo 1 > /tmp/linkstatus
  echo "$ip" > /tmp/linkip
  . /etc/init.d/SetPWM.sh 0 1000 50
  echo "Net:up"
  #ping $my_router -c 5 > /tmp/ping.log &
else
  echo 0 > /tmp/.iot_status
  echo 0 > /tmp/linkstatus
  . /etc/init.d/SetPWM.sh 0 3 20
  echo "Net:down"
fi
sync
. /etc/init.d/LogTime.sh "sta.e"

