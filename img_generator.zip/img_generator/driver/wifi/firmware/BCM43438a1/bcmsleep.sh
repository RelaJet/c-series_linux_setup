#!/bin/sh
./wl pkt_filter_enable 201 1
./wl pkt_filter_mode 1
./wl bcn_li_dtim 20
./wl PM 1
./dhd -iwlan0 sleep 1
poweroff