#!/bin/sh
ifconfig eth0 down
iot-tool -L