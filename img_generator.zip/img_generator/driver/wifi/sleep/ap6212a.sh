#!/bin/sh
# enable early notify in wifi firmware
dhd_priv wl earlynotify 1 
dhd_priv keep_alive 0 0
dhd_priv set_suspend_bcn_li_dtim 20
dhd_priv setsuspendmode 1
dhd -i wlan0 sleep 1


