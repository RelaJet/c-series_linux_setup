#!/bin/sh
iot-tool -L