#!/bin/sh
. ./config.mk 2> /dev/null
IMAGE=./image
COUNT=21504
DRIVER_MODULE=$ROOTFS_FOLDER/usr/modules
WIFI_FOLDER=driver/wifi
BT_FOLDER=driver/bluetooth
ETC_FIRMWARE=$ROOTFS_FOLDER/etc/firmware
USR_BIN=$ROOTFS_FOLDER/usr/bin
USR_LIB=$ROOTFS_FOLDER/usr/lib
CLOUDAPP_PATH=./app/$CLOUD_APP_FOLDER
SERVICEAPP_PATH=./app/$SERVICE_APP_FOLDER
WEBDCIM_SRC=$ROOTFS_FOLDER/var/webserver/www/DCIM
WEBDCIM_DST=/mnt/sdcard/DCIM
TEMP_ROOTFS=temp_rootfs
TEMP_ROOTFS1=temp_rootfs1
TEMP_EXTFS=temp_extfs
IVA_DATA=/mnt/mtd3/iva
IVA_BIN=$TEMP_EXTFS/iva

#delete /usr/modules and /etc/firmware first
#setup video and dual cpu settings
#./settings/setup_video_dualcpu.sh

#setup application
#./settings/setup_application.sh

#setup wifi settings
#./settings/setup_wifi.sh

#copy kernel modules
if [ "$ACTION_CAM" = "yes" ]; then
  echo "$ACTION_CAM_SENSOR" > $ROOTFS_FOLDER/etc/init.d/SENSOR

#Action Cam Prepare for wifi part 
	#if [ "$ACTION_CAM_WIFI_TYPE" != "iot" ]; then
	#	sed -i 's/etc/tmp/g' $ROOTFS_FOLDER/usr/wireless/sta.sh
	#fi

# wifi 
#	if [ "$wifi_in_kernel" = "yes" ]; then
#		rm -f $DRIVER_MODULE/$WIFI_NAME  
#	fi
#fi

#strip 
buildroot-2014.11/bin/arm-linux-strip $ROOTFS_FOLDER/usr/bin/* --strip-unneeded 2> /dev/null 
buildroot-2014.11/bin/arm-linux-strip $ROOTFS_FOLDER/usr/lib/* --strip-unneeded 2> /dev/null
buildroot-2014.11/bin/arm-linux-strip $ROOTFS_FOLDER/usr/modules/* --strip-unneeded 2> /dev/null

#duplicate rootfs
if [ -d $TEMP_ROOTFS ]; then
	sudo rm -rf $TEMP_ROOTFS
fi
if [ -d $TEMP_ROOTFS1 ]; then
	sudo rm -rf $TEMP_ROOTFS1
fi

if [ -d $TEMP_EXTFS ]; then
	sudo rm -rf $TEMP_EXTFS
fi

sudo cp -r $ROOTFS_FOLDER $TEMP_ROOTFS

#delete svn info
sudo rm -rf `find $TEMP_ROOTFS -type d -name .svn`
sync

#
# remove non-used bin files
#
if [ "$ACTION_CAM" = "yes" ]; then

  #
  if [ "$ACTION_CAM" = "yes" ]; then

    if [ "$ACTION_CAM_EMBEDDED_APP" != "" ]; then
    echo "Optimize $ACTION_CAM_EMBEDDED_APP,embedded it to $IMAGE/embedded_app.img"
    mkimage -A arm -O linux -T kernel -C none -a 0x1008000 -e 0x1008000 -n 'Embedded' -d $TEMP_ROOTFS/$ACTION_CAM_EMBEDDED_APP $IMAGE/embedded_app.img
    fi

  fi
fi


# ALSA drivers
#
  #mv $TEMP_ROOTFS/usr/modules/snd-timer.ko $TEMP_ROOTFS1/modules/snd-timer.ko
  #ln -s  /usr1/modules/snd-timer.ko $TEMP_ROOTFS/usr/modules/snd-timer.ko
  #mv $TEMP_ROOTFS/usr/modules/snd-page-alloc.ko $TEMP_ROOTFS1/modules/snd-page-alloc.ko
  #ln -s  /usr1/modules/snd-page-alloc.ko $TEMP_ROOTFS/usr/modules/snd-page-alloc.ko
  #mv $TEMP_ROOTFS/usr/modules/regmap-i2c.ko $TEMP_ROOTFS1/modules/regmap-i2c.ko
  #ln -s  /usr1/modules/regmap-i2c.ko $TEMP_ROOTFS/usr/modules/regmap-i2c.ko
  #mv $TEMP_ROOTFS/usr/modules/regmap-spi.ko $TEMP_ROOTFS1/modules/regmap-spi.ko
  #ln -s  /usr1/modules/regmap-spi.ko $TEMP_ROOTFS/usr/modules/regmap-spi.ko
  #mv $TEMP_ROOTFS/usr/modules/snd-pcm.ko $TEMP_ROOTFS1/modules/snd-pcm.ko
  #ln -s  /usr1/modules/snd-pcm.ko $TEMP_ROOTFS/usr/modules/snd-pcm.ko
  #mv $TEMP_ROOTFS/usr/modules/snd-soc-core.ko $TEMP_ROOTFS1/modules/snd-soc-core.ko
  #ln -s  /usr1/modules/snd-soc-core.ko $TEMP_ROOTFS/usr/modules/snd-soc-core.ko
  
  #mv $TEMP_ROOTFS/usr/modules/ait-ssc.ko $TEMP_ROOTFS1/modules/ait-ssc.ko
  #ln -s  /usr1/modules/ait-ssc.ko $TEMP_ROOTFS/usr/modules/ait-ssc.ko
  #mv $TEMP_ROOTFS/usr/modules/ait-afe-pcm.ko $TEMP_ROOTFS1/modules/ait-afe-pcm.ko
  #ln -s  /usr1/modules/ait-afe-pcm.ko $TEMP_ROOTFS/usr/modules/ait-afe-pcm.ko
  #mv $TEMP_ROOTFS/usr/modules/ait_afe_dai.ko $TEMP_ROOTFS1/modules/ait_afe_dai.ko
  #ln -s  /usr1/modules/ait_afe_dai.ko $TEMP_ROOTFS/usr/modules/ait_afe_dai.ko
  #mv $TEMP_ROOTFS/usr/modules/ait_evb_afe.ko $TEMP_ROOTFS1/modules/ait_evb_afe.ko
  #ln -s  /usr1/modules/ait_evb_afe.ko $TEMP_ROOTFS/usr/modules/ait_evb_afe.ko

	#generate customer partition
	./settings/ACT_PARTITION/gen_act_fs.sh
fi

#generate mtd3 partition
if [ `command -v mkfs.jffs2` ]; then

  if [ "$ACTION_CAM" = "yes" ]; then
	  sudo mkfs.jffs2 -r $TEMP_ROOTFS/mnt/mtd3 -e 0x10000 --pad=0x100000 -o $IMAGE/mtd3_jffs2.img 
	else
	  sudo mkfs.jffs2 -r $TEMP_ROOTFS/mnt/mtd3 -e 0x10000 --pad=0x80000 -o $IMAGE/mtd3_jffs2.img 	
	fi
else
	echo "Please get \"mkfs.jffs2\" (sudo apt-get install mtd-utils)"
	exit 1
fi

#generate rootfs
case "$1" in
EXT2)
	echo "Generate ext2 rootfs"
	dd if=/dev/zero of=rootfs.ext2 bs=1k count=$COUNT
	mke2fs -c rootfs.ext2 $COUNT
	mkdir rootfs_ext2
	sudo mount rootfs.ext2 rootfs_ext2 -t ext2
	sudo cp -av $TEMP_ROOTFS/* rootfs_ext2/
	sync
	bzip2 -9 -c rootfs.ext2 > rootfs.ext2.bz2
	cp rootfs.ext2.bz2 $IMAGE/rootfs_ext2.img
	sudo umount rootfs_ext2
	sudo rm -rf rootfs.ext2.bz2 rootfs_ext2 rootfs.ext2
	sync
	;;

UBI)
	echo "Generate UBI rootfs"
	sudo mkfs.ubifs -r $TEMP_ROOTFS -m 2048 -e 129024 -c 1024 -o ubifs.img
	ubinize -o ubi.img -m 2048 -p 128KiB -s 512 settings/ubinize.cfg
	cp ubi.img $IMAGE/rootfs_ubi.img
	rm -rf ubi.img ubifs.img
	sync
	;;

CRAM)
	echo "Generate CRAM rootfs"
	if [ `command -v mkcramfs` ]; then
		sudo mkcramfs $TEMP_ROOTFS rootfs_cram.img
		mv rootfs_cram.img $IMAGE/rootfs_cram.img
		sync
	else
		echo "Please get \"mkcramfs\" (sudo apt-get install cramfsprogs)"
		exit 1
        fi
	;;
SQFS)
	echo "Generate Squash rootfs"
	if [ `command -v mksquashfs` ]; then
	  if [ "$ACTION_CAM" = "yes" ]; then
		sudo mksquashfs $TEMP_ROOTFS rootfs_cram.img -noappend -comp lzo
		sudo mksquashfs $TEMP_ROOTFS1 rootfs_cram1.img -noappend -comp lzo
		mv rootfs_cram1.img $IMAGE/rootfs_cram1.img
		# here move to new layout method,act_partition.config
		#sudo mksquashfs $TEMP_EXTFS extfs_oem.img -noappend -comp lzo
		#mv extfs_oem.img $IMAGE/extfs_oem.img
	  else
		sudo mksquashfs $TEMP_ROOTFS rootfs_cram.img -noappend -comp xz	  
	  fi
		mv rootfs_cram.img $IMAGE/rootfs_cram.img
		sync
	else 
		echo "Please get \"mksquashfs\" (sudo apt-get install squashfs-tools)"
		exit 1
	fi
	;;
EXT4)
	#just copy rootfs 
	if [ -d $IMAGE/$ROOTFS_FOLDER ]; then
		sudo rm -rf $IMAGE/$ROOTFS_FOLDER
	fi
	sudo cp -r $TEMP_ROOTFS $IMAGE/$ROOTFS_FOLDER
	if [ "$CLOUD" = "yes" ]; then
			sudo cp $SERVICEAPP_PATH/bin/babyCryDetect $TEMP_ROOTFS/usr/cloud_daemon/babyCryDetect			
	fi
	if [ "$FD_FR_ROOTFS" = "yes" ]; then
		if [ "$CLOUD" = "yes" ]; then
			sudo cp -av $SERVICEAPP_PATH/capture_fd/ROMfiles $TEMP_ROOTFS/usr/cloud_daemon/
			sudo cp $SERVICEAPP_PATH/bin/fdcapture $TEMP_ROOTFS/usr/cloud_daemon/
		fi
	fi
	if [ "$DDR3_TEST" = "yes" ]; then
		sudo mkdir $ROOTFS_FOLDER/usr/extract_to_memory_test
		sudo cp -a extract_to_memory_test/extract_to_memory_test.sh $TEMP_ROOTFS/usr/extract_to_memory_test
		sudo cp -a extract_to_memory_test/share.tar.xz $TEMP_ROOTFS/usr/extract_to_memory_test
		sudo cp -a extract_to_memory_test/tar $TEMP_ROOTFS/usr/extract_to_memory_test/tar
	fi
	#generate image
	if [ `command -v parted` ] && [ `command -v losetup` ] && [ `command -v mkfs.vfat` ] && [ `command -v mkfs.ext4` ]; then
		rm -rf $IMAGE/rootfs_ext4.img
		dd if=/dev/zero of=rootfs_ext4.img bs=1024 count=0 seek=$((1024*$EXT4_IMAGE_SIZE))
		sudo losetup /dev/loop0 rootfs_ext4.img
		sudo parted -s /dev/loop0 mklabel msdos
		sudo parted -s /dev/loop0 mkpart primary fat32 0MiB 32MiB
		sudo parted -s /dev/loop0 mkpart primary ext4 32MiB 128MiB
		if [ $EXT4_IMAGE_SIZE -gt 256 ]; then
			sudo parted -s /dev/loop0 mkpart primary fat32 128MiB $EXT4_IMAGE_SIZE"MiB"
			sudo mkfs.vfat /dev/loop0p3
		fi
		sudo mkfs.vfat /dev/loop0p1
		sudo mkfs.ext4 /dev/loop0p2
		sudo mount /dev/loop0p1 $IMAGE/$ROOTFS_FOLDER
		sync
		sudo cp $IMAGE/SdFwCode.bin $IMAGE/$ROOTFS_FOLDER/SdFwCode.bin
		sudo cp $IMAGE/U-boot.bin $IMAGE/$ROOTFS_FOLDER/U-boot.bin
		sudo cp $IMAGE/uImage $IMAGE/$ROOTFS_FOLDER/UImage
		sync
		sleep 5
		sudo umount $IMAGE/$ROOTFS_FOLDER
		sync
		sudo mount /dev/loop0p2 $IMAGE/$ROOTFS_FOLDER
		sync
		sudo cp -r $TEMP_ROOTFS/* $IMAGE/$ROOTFS_FOLDER/
		sync
		sleep 5
		sudo umount $IMAGE/$ROOTFS_FOLDER
		sync
		sudo losetup -d /dev/loop0
		sudo cp -r $TEMP_ROOTFS/* $IMAGE/$ROOTFS_FOLDER/
		mv rootfs_ext4.img $IMAGE/
	else
		echo "Please get \"parted losetup mkfs.vfat mkfs.ext4\""
	fi
	;;
*)
	echo "ERROR: unknown file system type"
	;;
esac

#delete temp_rootfs
if [ -d $TEMP_ROOTFS ]; then
	sudo rm -rf $TEMP_ROOTFS
fi
if [ -d $TEMP_ROOTFS1 ]; then
	sudo rm -rf $TEMP_ROOTFS1
fi
if [ -d $TEMP_EXTFS ]; then
	sudo rm -rf $TEMP_EXTFS
fi

echo "Generate ROOTFS Done"
