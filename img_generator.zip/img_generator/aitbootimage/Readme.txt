[Read Me]
1. SdFwCode.bin is ait boot loader which support 
    a. SD/EMMC boot
    b. Parallel Nand boot
    c. Serial Nand boot : NA (not tested )

2. SfFwCode.bin is for serial flash boot

3. ait boot loader also support updating flash image 
   from Sd-Card to 
   a. eMMC ( SD1 )
   b. Parallel Nand
   c. Serial Flash
   d. Serial Nand : NA ( not test )
   
4. How to update flash image to eMMC / Parallel Nand / Serial Flash / Serial Nand
   
   1. Put Updater.txt into Sd-card, with the following format:
   
   a. Update image to EMMC
   [SD2EMMC]
   SD:\FlashImage.bin,0x00
   
   b. Update image to Parallel Nand
   
   [SD2PANand]
   SD:\SdFwCode.bin,0x00
   SD:\U-boot_PANAND.bin,0x20000
   SD:\uImage,0x100000
   SD:\Ubi-Rootfs.bin,0x600000
   
   c. Update image to serial flash
   [SD2SF]
   SD:\FlashImage.bin,0x00
   
   d. Update image to serial nand
   [SD2SNand]
   SD:\FlashImage,0x00
   
   2. Put the images to sd-card
   
   3. Boot from SD0 (FAT boot)
   
   
   
   
   
   



